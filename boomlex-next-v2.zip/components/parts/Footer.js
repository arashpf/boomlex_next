import * as React from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import styles from "../styles/Footer.module.css";
import "font-awesome/css/font-awesome.min.css";
import Image from "next/image";
import BottomNavigation from "@mui/material/BottomNavigation";
import BottomNavigationAction from "@mui/material/BottomNavigationAction";

import CampaignIcon from "@mui/icons-material/Campaign";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import HomeIcon from "@mui/icons-material/Home";
import SearchIcon from "@mui/icons-material/Search";
import FavoriteIcon from "@mui/icons-material/Favorite";
import PersonIcon from "@mui/icons-material/Person";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";
import ShareLocationIcon from "@mui/icons-material/ShareLocation";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";

import Paper from "@mui/material/Paper";
import { useRouter } from "next/router";
import Cookies from "js-cookie";
import Link from "next/link";

import useAuthGate from "../../hooks/useAuthGate";

// Label styling shared by all tabs
const labelStyle = (isActive) => ({
  fontFamily: "iransans, Arial, sans-serif",
  fontSize: 11,
  lineHeight: 1,
  marginTop: 2,
  color: isActive ? "#fff" : "rgba(0,0,0,0.55)",
  transition: "color 220ms ease",
  userSelect: "none",
});

const Footer = () => {
  const router = useRouter();
  const { requireAuth } = useAuthGate();
  const [value, setValue] = React.useState(0);
  const ref = React.useRef(null);
  const prevValueRef = React.useRef(0);
  const touchStartRef = React.useRef(null);
  const touchMovedRef = React.useRef(false);

  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  // keep the footer selector in sync with current route
  const routeToIndex = (path) => {
    if (!path) return 0;
    const base = path.split("?")[0].split("#")[0];
    if (base === "/" || base === "/index" || base === "/search") return 0;
    if (base.startsWith("/favorites")) return 1;
    if (base.startsWith("/panel/new")) return 2;
    if (base.startsWith("/assistant")) return 3;
    if (base.startsWith("/panel")) return 4;
    return 0;
  };

  React.useEffect(() => {
    try {
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      const idx = routeToIndex(base);
      setValue(idx);
    } catch (err) {
      // ignore
    }
  }, [router && router.asPath]);

  const renderFixedFooterNav = () => {
    const onClickHome = () => {
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      if (base !== "/") router.push("/");
    };

    const onClickSearch = () => {
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      if (base !== "/") router.push("/");
    };

    const onClickFavorites = () => {
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      if (base !== "/favorites") router.push("/favorites");
    };

    const onClickMap = () => {
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      if (base !== "/map") router.push("/map");
    };

    // ─── افزودن: requires login (opens AuthModal for guests) ───
    const onClickNew = () => {
      requireAuth(
        () => {
          const base =
            router && router.asPath
              ? router.asPath.split("?")[0]
              : router.pathname;
          if (base !== "/panel/new") router.push("/panel/new");
        },
        "برای ثبت آگهی جدید وارد شوید"
      );
    };

    // ─── پروفایل: requires login (opens AuthModal for guests) ───
    const onClickMyDashboard = () => {
      requireAuth(
        () => {
          setValue(4);
          const base =
            router && router.asPath
              ? router.asPath.split("?")[0]
              : router.pathname;
          if (base !== "/panel") router.push("/panel");
        },
        "برای مشاهده پنل شخصی وارد شوید"
      );
    };

    const onClickMarketing = () => {
      var token = Cookies.get("id_token");
      const base =
        router && router.asPath ? router.asPath.split("?")[0] : router.pathname;
      if (token) {
        if (base !== "/marketing/single") router.push("/marketing/single");
      } else {
        if (base !== "/marketing") router.push("/marketing");
      }
    };

    const footerNode = (
      <div className={styles["fixed-footer-wrapper"]}>
        <div
          style={{
            position: "fixed",
            bottom: -4,
            left: 0,
            right: 0,
            zIndex: 1000,
            height: "var(--bottom-nav-height)",
            background: "rgba(255, 255, 255, 0)",
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
            margin: "0 0",
            overflow: "visible",
          }}
        >
          <div
            style={{
              position: "absolute",
              left: "50%",
              transform: "translateX(-50%)",
              bottom: 0,
              width: "min(720px, calc(100% - 40px))",
              height: "calc(var(--bottom-nav-height) - 4px)",
              borderRadius: 9999,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "10px 0 0 0",
              boxSizing: "border-box",
            }}
          >
            {/* subtle background oval */}
            <div
              style={{
                position: "absolute",
                left: 0,
                right: 0,
                height: 52,
                bottom: 7,
                margin: "0 auto",
                borderRadius: 9999,
                background: "rgba(236, 236, 236, 0.8)",
                backdropFilter: "blur(12px) saturate(1.1)",
                WebkitBackdropFilter: "blur(6px)",
                boxShadow: "inset -4px 3px 15px rgba(199, 199, 199, 0.29)",
              }}
            />

            {/* active pill */}
            <div
              style={{
                position: "absolute",
                top: "53%",
                left: `${
                  value === 0
                    ? "10%"
                    : value === 1
                    ? "30%"
                    : value === 2
                    ? "50%"
                    : value === 3
                    ? "70%"
                    : "90%"
                }`,
                height: value === 2 ? 0 : 53,
                width: value === 2 ? 0 : `calc(20% - 5px)`,
                borderRadius: 9999,
                transform: "translate(-50%, -50%)",
                transition:
                  "left 520ms cubic-bezier(0.175,0.885,0.32,1.275), height 320ms ease, width 320ms ease",
                boxShadow:
                  value === 2
                    ? "none"
                    : "0 8px 20px rgba(185,39,46,0.14), inset 0 2px 6px rgba(255,255,255,0.06)",
                background:
                  "linear-gradient(135deg, rgba(192,36,42,0.9), rgba(170,30,36,0.75))",
                border: "1px solid rgba(255,255,255,0.06)",
                zIndex: 2,
              }}
              aria-hidden
            />

            {/* 1 — خانه */}
            <div
              onClick={() => {
                setValue(0);
                onClickHome();
              }}
              role="button"
              aria-label="خانه"
              style={{
                position: "relative",
                zIndex: 3,
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                padding: "6px 0",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <HomeIcon
                  style={{
                    color: value === 0 ? "#fff" : "rgba(0,0,0,0.50)",
                    fontSize: 26,
                    transition: "color 220ms ease",
                  }}
                />
                <span style={labelStyle(value === 0)}>خانه</span>
              </div>
            </div>

            {/* 2 — موردعلاقه‌ها */}
            <div
              onClick={() => {
                setValue(1);
                onClickFavorites();
              }}
              role="button"
              aria-label="موردعلاقه ها"
              style={{
                position: "relative",
                zIndex: 3,
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                padding: "6px 0",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <FavoriteBorderIcon
                  style={{
                    color: value === 1 ? "#fff" : "rgba(0,0,0,0.50)",
                    fontSize: 26,
                    transition: "color 220ms ease",
                  }}
                />
                <span style={labelStyle(value === 1)}>موردعلاقه‌ها</span>
              </div>
            </div>

            {/* 3 — افزودن جدید (center FAB) */}
            <div
              onClick={() => {
                setValue(2);
                onClickNew();
              }}
              role="button"
              aria-label="افزودن جدید"
              style={{
                position: "relative",
                zIndex: 3,
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                padding: "6px 0",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <div
                  style={{
                    position: "relative",
                    width: 56,
                    height: 56,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <div
                    style={{
                      position: "absolute",
                      width: "100%",
                      height: "100%",
                      borderRadius: "50%",
                      background:
                        "linear-gradient(135deg, #ff3030, #d41c1c)",
                      boxShadow: "0 6px 20px rgba(255, 48, 48, 0.4)",
                    }}
                  />
                  <div style={{ position: "relative", zIndex: 1 }}>
                    <svg
                      width="32"
                      height="32"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="white"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <line x1="12" y1="5" x2="12" y2="19" />
                      <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                  </div>
                </div>
                <span style={labelStyle(false)}>افزودن</span>
              </div>
            </div>

            {/* 4 — ابزارها */}
            <div
              role="button"
              aria-label="ابزارها"
              style={{
                position: "relative",
                zIndex: 3,
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                padding: "6px 0",
              }}
              onTouchStart={(e) => {
                touchMovedRef.current = false;
                e && e.stopPropagation && e.stopPropagation();
                if (e.touches && e.touches[0])
                  touchStartRef.current = e.touches[0].clientY;
              }}
              onTouchMove={(e) => {
                if (!touchStartRef.current) return;
                const currentY =
                  e.touches && e.touches[0] ? e.touches[0].clientY : null;
                if (
                  currentY !== null &&
                  Math.abs(currentY - touchStartRef.current) > 10
                ) {
                  touchMovedRef.current = true;
                }
              }}
              onTouchEnd={(e) => {
                e && e.stopPropagation && e.stopPropagation();
                e && e.preventDefault && e.preventDefault();
                if (!touchMovedRef.current) {
                  prevValueRef.current = value;
                  setValue(3);
                  try {
                    const base =
                      router && router.asPath
                        ? router.asPath.split("?")[0]
                        : router.pathname;
                    if (base !== "/assistant") router.push("/assistant");
                  } catch (err) {}
                }
                touchStartRef.current = null;
                touchMovedRef.current = false;
              }}
              onClick={(e) => {
                e && e.stopPropagation && e.stopPropagation();
                e && e.preventDefault && e.preventDefault();
                if (touchMovedRef.current) return;
                prevValueRef.current = value;
                setValue(3);
                try {
                  const base =
                    router && router.asPath
                      ? router.asPath.split("?")[0]
                      : router.pathname;
                  if (base !== "/assistant") router.push("/assistant");
                } catch (err) {}
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <AutoAwesomeIcon
                  style={{
                    color: value === 3 ? "#fff" : "rgba(0,0,0,0.50)",
                    fontSize: 30,
                    transition: "color 220ms ease",
                  }}
                />
                <span style={labelStyle(value === 3)}>ابزارها</span>
              </div>
            </div>

            {/* 5 — پروفایل */}
            <div
              onClick={() => {
                setValue(4);
                onClickMyDashboard();
              }}
              role="button"
              aria-label="پروفایل"
              style={{
                position: "relative",
                zIndex: 3,
                flex: 1,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                cursor: "pointer",
                padding: "6px 0",
              }}
            >
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <PersonIcon
                  style={{
                    color: value === 4 ? "#fff" : "rgba(0,0,0,0.50)",
                    fontSize: 26,
                    transition: "color 220ms ease",
                  }}
                />
                <span style={labelStyle(value === 4)}>پروفایل</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );

    if (typeof document !== "undefined" && mounted) {
      return ReactDOM.createPortal(footerNode, document.body);
    }

    return footerNode;
  };

  return <div>{renderFixedFooterNav()}</div>;
};

export default Footer;