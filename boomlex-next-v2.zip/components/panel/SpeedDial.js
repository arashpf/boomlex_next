import * as React from 'react';
import Box from '@mui/material/Box';
import SpeedDial from '@mui/material/SpeedDial';
import SpeedDialIcon from '@mui/material/SpeedDialIcon';
import AddIcCallIcon from '@mui/icons-material/AddIcCall';
import CallIcon from '@mui/icons-material/Call';
import Share from '@mui/icons-material/Share';
import AddCircle from '@mui/icons-material/AddCircle';
import Add from '@mui/icons-material/Add';
import SpeedDialAction from '@mui/material/SpeedDialAction';
import FileCopyIcon from '@mui/icons-material/FileCopyOutlined';
import SaveIcon from '@mui/icons-material/Save';
import { useRouter } from 'next/router';

//handler function


const actions = [
    { icon: <AddCircle />, name: 'فایل جدید',  operation: 'new'},
    { icon: <Share />, name: 'اشتراک گذاری ',  operation: 'share' }
  ]

export default function BasicSpeedDial({ open = false, drawerWidth = 250 }) {
    const router = useRouter();

    function handleClick (e, operation) {
      console.log('speed dial clicked');
      router.push("/panel/new");
      e.preventDefault();
    }
     
  return (
    <div className="speed-dial-fixed">
    <Box md={{ height: 320, transform: 'translateZ(0px)', flexGrow: 1 }}>
      <SpeedDial
        ariaLabel="ثبت فایل جدید"
        sx={{ 
          position: 'fixed', 
          bottom: 90, 
          right: open ? `calc(16px + ${drawerWidth}px)` : 16,
          transition: (theme) =>
            theme.transitions.create(['right'], {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }),
        }}
        icon={<Add />}
        onClick={handleClick}
        FabProps={{
          sx: {
            bgcolor: '#7a97ff',
            '&:hover': {
              bgcolor: 'primary.main',
            }
          }
        }}
      >
     
      </SpeedDial>
    </Box>
    </div>
  );
}
