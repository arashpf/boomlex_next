import React, { useState, useEffect, useRef } from "react";
import {
  MapContainer,
  TileLayer,
  useMapEvents,
  LayersControl,
} from "react-leaflet";
import "leaflet-defaulticon-compatibility/dist/leaflet-defaulticon-compatibility.css";
import "leaflet-defaulticon-compatibility";
import "leaflet/dist/leaflet.css";
import Styles from "../../styles/panel/LocationForm.module.css";
import Button from "@mui/material/Button";
import axios from "axios";
import Cookies from "js-cookie";
import { useRouter } from "next/router";
import MuiAlert from "@mui/material/Alert";
import Snackbar from "@mui/material/Snackbar";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import FormControl from "@mui/material/FormControl";
import Paper from "@mui/material/Paper";
import Autocomplete from "@mui/material/Autocomplete";
import FormHelperText from "@mui/material/FormHelperText";
import SearchIcon from "@mui/icons-material/Search";
import Typography from "@mui/material/Typography";
import Fade from "@mui/material/Fade";
import LinearProgress from "@mui/material/LinearProgress";
import IconButton from "@mui/material/IconButton";
import RefreshIcon from "@mui/icons-material/Refresh";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import WarningIcon from "@mui/icons-material/Warning";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CloseIcon from "@mui/icons-material/Close";
import RoomIcon from "@mui/icons-material/Room";
import MyLocationIcon from "@mui/icons-material/MyLocation";
import Modal from "@mui/material/Modal";
import Chip from "@mui/material/Chip";

const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

// Permission Dialog Component
const PermissionDialog = ({ open, onClose }) => {
  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="permission-dialog"
    >
      <Fade in={open}>
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '90%',
          maxWidth: 400,
          bgcolor: 'background.paper',
          borderRadius: 4,
          boxShadow: 24,
          p: 3,
        }}>
          <Typography variant="h6" sx={{ mb: 2, color: '#ff5252' }}>
            دسترسی به موقعیت مکانی
          </Typography>
          <Typography variant="body2" sx={{ mb: 3 }}>
            برای استفاده از موقعیت مکانی فعلی، لطفا دسترسی را در مرورگر خود فعال کنید:
          </Typography>

          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" fontWeight="bold">کروم:</Typography>
            <Typography variant="caption" color="textSecondary">
              روی آیکون قفل در نوار آدرس کلیک کنید ← تنظیمات سایت ← موقعیت مکانی ← اجازه
            </Typography>
          </Box>

          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" fontWeight="bold">فایرفاکس:</Typography>
            <Typography variant="caption" color="textSecondary">
              روی آیکون اطلاعات در نوار آدرس کلیک کنید ← دسترسی‌ها ← موقعیت مکانی
            </Typography>
          </Box>

          <Box sx={{ mb: 3 }}>
            <Typography variant="body2" fontWeight="bold">سافاری:</Typography>
            <Typography variant="caption" color="textSecondary">
              Safari ← تنظیمات ← وبسایت‌ها ← موقعیت مکانی
            </Typography>
          </Box>

          <Button
            variant="contained"
            fullWidth
            onClick={onClose}
            sx={{
              py: 1.5,
              borderRadius: 3,
              background: 'linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%)',
            }}
          >
            متوجه شدم
          </Button>
        </Box>
      </Fade>
    </Modal>
  );
};

function LocationForm(props) { 
  const returnedWorker = props.returnedWorker;
  const router = useRouter();
  const edit_id = props.edit_id;

  // Neshan API key
  const NESHAN_API_KEY = "service.df4c9bbc16704476847da9b6b5cf892e";

  // Step management
  const [currentStep, setCurrentStep] = useState(2); // 1: Map, 2: Form Modal

  // Local Iranian cities database for fallback when APIs are blocked
const IRANIAN_CITIES = [
  { name: "تهران", lat: 35.6892, lng: 51.3890, province: "تهران" },
  { name: "مشهد", lat: 36.2605, lng: 59.6168, province: "خراسان رضوی" },
  { name: "اصفهان", lat: 32.6546, lng: 51.6680, province: "اصفهان" },
  { name: "کرج", lat: 35.8400, lng: 50.9391, province: "البرز" },
  { name: "تبریز", lat: 38.0962, lng: 46.2738, province: "آذربایجان شرقی" },
  { name: "شیراز", lat: 29.5918, lng: 52.5837, province: "فارس" },
  { name: "اهواز", lat: 31.3183, lng: 48.6706, province: "خوزستان" },
  { name: "قم", lat: 34.6399, lng: 50.8759, province: "قم" },
  { name: "کرمانشاه", lat: 34.3142, lng: 47.0650, province: "کرمانشاه" },
  { name: "ارومیه", lat: 37.5527, lng: 45.0759, province: "آذربایجان غربی" },
  // Add more cities as needed
];

const TEHRAN_NEIGHBORHOODS = [
  { name: "آزادی", lat: 35.6997, lng: 51.3381 },
  { name: "تجریش", lat: 35.8045, lng: 51.4280 },
  { name: "ونک", lat: 35.7540, lng: 51.4060 },
  { name: "سعادت آباد", lat: 35.7740, lng: 51.3650 },
  { name: "پاسداران", lat: 35.7690, lng: 51.4740 },
  { name: "نیاوران", lat: 35.8120, lng: 51.4720 },
  { name: "جنت آباد", lat: 35.7320, lng: 51.3050 },
  { name: "تهرانپارس", lat: 35.7010, lng: 51.5480 },
  // Add more neighborhoods as needed
];


  const [selectedPosition, setSelectedPosition] = useState([35.6997, 51.3381]); // Azadi Tower

  const [isSelected, set_isSelected] = useState(true);
  const [addressRegion, set_addressRegion] = useState("");
  const [addressNeighbourhood, set_addressNeighbourhood] = useState("");
  const [addressCity, set_addressCity] = useState("");
  const [addressMunicipality_zone, set_addressMunicipality_zone] = useState("");
  const [addressState, set_addressState] = useState("");
  const [addressFormatted, set_addressFormatted] = useState("");
  const [zoomLevel, set_zoomLevel] = useState(15);

  const [final_lat, set_final_lat] = useState(35.6892);
  const [final_lng, set_final_lng] = useState(51.3890);
  const [city_lat, set_city_lat] = useState();
  const [city_lng, set_city_lng] = useState();

  const [openSnackBar, setOpenSnackBar] = useState(false);
  const [problem, setProblem] = useState("");
  const [alert_sevirity, set_alert_sevirity] = useState("warning");
  const [btn_status, set_btn_status] = useState(false);
  const [available_cities, set_available_cities] = useState([]);
  const [available_neighborhoods, set_available_neighborhoods] = useState([]);

  // Validation states
  const [validationErrors, setValidationErrors] = useState({
    city: false,
    neighborhood: false,
    address: false
  });

  // Touched states for showing validation
  const [touched, setTouched] = useState({
    city: false,
    neighborhood: false,
    address: false
  });

  // Add state for search functionality
  const [citySearch, setCitySearch] = useState("");
  const [neighborhoodSearch, setNeighborhoodSearch] = useState("");
  const [filteredCities, setFilteredCities] = useState([]);
  const [filteredNeighborhoods, setFilteredNeighborhoods] = useState([]);

  // New state for search functionality
  const [placeSearchQuery, setPlaceSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchApi, setSearchApi] = useState("neshan"); // Track which API is being used

  // State for confirmation modal
  const [showConfirmationModal, setShowConfirmationModal] = useState(true);

  // State for permission dialog
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);

  // Enhanced loading state for map center
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [geocodingError, setGeocodingError] = useState(false);
  const [geocodingTimeout, setGeocodingTimeout] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const [geocodingApi, setGeocodingApi] = useState("neshan"); // Track which API is being used

  // Pin animation state
  const [isMapMoving, setIsMapMoving] = useState(false);
  const [pinScale, setPinScale] = useState(1);


  // Refs for timeout management
  const geocodingTimeoutRef = useRef(null);
  const geocodingAttemptRef = useRef(0);
  const abortControllerRef = useRef(null);
  const mapRef = useRef(null);
  const moveTimeoutRef = useRef(null);

  // Max retry attempts
  const MAX_RETRY_ATTEMPTS = 2;

  // Initialize filtered lists when data loads
  useEffect(() => {
    setFilteredCities(available_cities);
  }, [available_cities]);

  // Update filtered neighborhoods when city changes - using city_id with == for type coercion
  useEffect(() => {
    if (addressCity) {
      const selectedCity = available_cities.find(city => city.title === addressCity);
      if (selectedCity) {
        setFilteredNeighborhoods(
          available_neighborhoods.filter((nb) => nb.city_id == selectedCity.id)
        );
      } else {
        setFilteredNeighborhoods([]);
      }
    } else {
      setFilteredNeighborhoods([]);
    }
  }, [addressCity, available_neighborhoods, available_cities]);

  // Filter cities based on search
  useEffect(() => {
    if (citySearch) {
      const filtered = available_cities.filter((city) =>
        city.title?.toLowerCase().includes(citySearch.toLowerCase())
      );
      setFilteredCities(filtered);
    } else {
      setFilteredCities(available_cities);
    }
  }, [citySearch, available_cities]);

  // Filter neighborhoods based on search
  useEffect(() => {
    if (neighborhoodSearch && addressCity) {
      const selectedCity = available_cities.find(city => city.title === addressCity);
      if (selectedCity) {
        const filtered = available_neighborhoods.filter(
          (nb) =>
            nb.city_id == selectedCity.id &&
            nb.name?.toLowerCase().includes(neighborhoodSearch.toLowerCase())
        );
        setFilteredNeighborhoods(filtered);
      }
    } else if (addressCity) {
      const selectedCity = available_cities.find(city => city.title === addressCity);
      if (selectedCity) {
        setFilteredNeighborhoods(
          available_neighborhoods.filter((nb) => nb.city_id == selectedCity.id)
        );
      }
    } else {
      setFilteredNeighborhoods([]);
    }
  }, [neighborhoodSearch, addressCity, available_neighborhoods, available_cities]);

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (geocodingTimeoutRef.current) {
        clearTimeout(geocodingTimeoutRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      if (moveTimeoutRef.current) {
        clearTimeout(moveTimeoutRef.current);
      }
    };
  }, []);

  // Validate form fields
  const validateField = (field, value) => {
    switch (field) {
      case 'city':
        return !value || value.trim() === '';
      case 'neighborhood':
        return !addressCity || !value || value.trim() === '';
      case 'address':
        return !value || value.trim() === '';
      default:
        return false;
    }
  };

  // Update validation errors
  useEffect(() => {
    setValidationErrors({
      city: validateField('city', addressCity),
      neighborhood: validateField('neighborhood', addressNeighbourhood),
      address: validateField('address', addressFormatted)
    });
  }, [addressCity, addressNeighbourhood, addressFormatted]);

  // Handle field blur for showing validation
  const handleFieldBlur = (field) => {
    setTouched(prev => ({
      ...prev,
      [field]: true
    }));
  };

  // Helper function to create clean address without postal code and country
  const formatCleanAddress = (displayName) => {
    if (!displayName) return "";

    // Split by comma and clean each part
    const parts = displayName.split(',').map(part => part.trim());

    // Filter out postal codes (numbers with 5+ digits) and "ایران"
    const cleanParts = parts.filter(part => {
      // Check if part is a postal code (contains only digits and optional dash, length > 4)
      const isPostalCode = /^[\d-]{5,}$/.test(part.replace(/\s/g, ''));
      const isIran = part.includes('ایران') || part.includes('Iran');
      return !isPostalCode && !isIran;
    });

    return cleanParts.join('، ');
  };

  // Format Neshan address
  const formatNeshanAddress = (address) => {
    if (!address) return "";

    // Neshan returns address as a string, we can use it directly
    // Remove "ایران" if present
    return address.replace('، ایران', '').replace(', Iran', '');
  };

  // Extract city from Neshan address
  const extractCityFromNeshan = (address, cityObject) => {
    if (!address) return "";

    // Try to get city from city object if available
    if (cityObject && cityObject.name) {
      const matchedCity = matchCityFromApi(cityObject.name);
      if (matchedCity) return matchedCity;
    }

    // Try to extract from address string
    const parts = address.split('،');
    for (const part of parts) {
      const trimmed = part.trim();
      const matchedCity = matchCityFromApi(trimmed);
      if (matchedCity) return matchedCity;
    }

    return "";
  };

  // Extract neighborhood from Neshan address
  const extractNeighborhoodFromNeshan = (address, neighbourhoodObject) => {
    if (!address) return "";

    // Try to get neighborhood from neighbourhood object if available
    if (neighbourhoodObject && neighbourhoodObject.name) {
      return neighbourhoodObject.name;
    }

    // Try to extract from address string (usually the first part)
    const parts = address.split('،');
    return parts[0] || "";
  };

  // Extract city from address parts and match with available cities
  const matchCityFromApi = (cityName) => {
    if (!cityName || !available_cities.length) return "";

    // Try exact match first
    const exactMatch = available_cities.find(
      city => city.title === cityName
    );

    if (exactMatch) return exactMatch.title;

    // Try partial match
    const partialMatch = available_cities.find(
      city => cityName.includes(city.title) || city.title.includes(cityName)
    );

    return partialMatch ? partialMatch.title : "";
  };

  // Search for places using Neshan API (primary) with OpenStreetMap fallback
  // Search for places using Neshan API (primary) with OpenStreetMap fallback
  // Search for places using Neshan API (primary) with OpenStreetMap fallback
  const searchPlaces = async (query) => {
    if (!query || query.length < 3) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    setSearchApi("neshan");

    try {
      // Try Neshan API first - using the exact format from documentation
      try {
        const myHeaders = new Headers();
        myHeaders.append("Api-Key", NESHAN_API_KEY);

        const requestOptions = {
          method: "GET",
          headers: myHeaders,
          redirect: "follow"
        };

        const response = await fetch(
          `https://api.neshan.org/v1/search?term=${encodeURIComponent(query)}&lat=${selectedPosition[0]}&lng=${selectedPosition[1]}`,
          requestOptions
        );

        if (!response.ok) {
          console.log(`Neshan API returned status: ${response.status}`);
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log("Neshan search response:", data);

        if (data && data.items && data.items.length > 0) {
          const results = data.items.map(item => ({
            display_name: item.title,
            clean_display_name: item.address || item.title,
            lat: parseFloat(item.location.y),
            lon: parseFloat(item.location.x),
            type: item.type,
            category: item.category,
            neighbourhood: item.neighbourhood,
            region: item.region,
            address: item.address,
            source: "neshan"
          }));

          setSearchResults(results);
          setIsSearching(false);
          return;
        } else {
          // If no results from Neshan, try OSM
          throw new Error("No results from Neshan");
        }
      } catch (neshanError) {
        console.log("Neshan search failed, trying OpenStreetMap...", neshanError.message);

        // Fallback to OpenStreetMap - without User-Agent header
        setSearchApi("osm");
        try {
          // Use axios without the problematic User-Agent header
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/search`,
            {
              params: {
                q: query,
                format: "json",
                limit: 10,
                'accept-language': 'fa-IR',
                countrycodes: 'ir',
                viewbox: '44.0,24.0,64.0,40.0',
                bounded: 1
              },
              // Remove the headers section that was causing the error
              timeout: 10000,
            }
          );

          if (response.data && response.data.length > 0) {
            const results = response.data.map(item => ({
              display_name: item.display_name,
              clean_display_name: formatCleanAddress(item.display_name),
              lat: parseFloat(item.lat),
              lon: parseFloat(item.lon),
              type: item.type,
              class: item.class,
              importance: item.importance,
              source: "osm"
            }));

            results.sort((a, b) => b.importance - a.importance);
            setSearchResults(results);
          } else {
            setSearchResults([]);
          }
        } catch (osmError) {
          console.error("OSM search error:", osmError);
          setSearchResults([]);

          let errorMessage = "خطا در جستجوی مکان";
          if (osmError.code === 'ECONNABORTED' || osmError.message.includes('timeout')) {
            errorMessage = "زمان جستجو به پایان رسید";
          }
          setProblem(errorMessage);
          setOpenSnackBar(true);
        }
      }
    } catch (error) {
      console.error("Search error:", error);
      setSearchResults([]);

      let errorMessage = "خطا در جستجوی مکان";
      setProblem(errorMessage);
      setOpenSnackBar(true);
    } finally {
      setIsSearching(false);
    }
  };

  const handlePlaceSelect = (place) => {
    if (place) {
      const lat = place.lat;
      const lng = place.lon;

      setSelectedPosition([lat, lng]);
      set_final_lat(lat);
      set_final_lng(lng);
      set_isSelected(true);

      if (place.source === "neshan") {
        // Handle Neshan result
        const cleanAddress = formatNeshanAddress(place.address || place.display_name);
        set_addressFormatted(cleanAddress);
        set_addressRegion(cleanAddress);

        // Extract city and neighborhood
        const matchedCity = extractCityFromNeshan(cleanAddress, place.city);
        const neighborhood = extractNeighborhoodFromNeshan(cleanAddress, place.neighbourhood);

        set_addressCity(matchedCity || "");
        set_addressNeighbourhood(neighborhood);
        set_addressState(place.state || "");
      } else {
        // Handle OSM result
        const cleanDisplayName = place.clean_display_name || formatCleanAddress(place.display_name);
        const addressParts = cleanDisplayName.split('، ');

        const cityFromParts = addressParts.find(part =>
          available_cities.some(city => part.includes(city.title) || city.title.includes(part))
        ) || addressParts[1] || addressParts[0];

        const matchedCity = matchCityFromApi(cityFromParts);
        const neighborhood = addressParts[0] || "";

        set_addressCity(matchedCity || "");
        set_addressNeighbourhood(neighborhood);
        set_addressState("");
        set_addressFormatted(cleanDisplayName);
        set_addressRegion(cleanDisplayName);
      }

      set_addressMunicipality_zone("");
      setPlaceSearchQuery("");
      setSearchResults([]);

      // Reset touched states
      setTouched({
        city: false,
        neighborhood: false,
        address: false
      });

      // Fly to the location
      if (mapRef.current) {
        mapRef.current.flyTo([lat, lng], 17);
      }
    }
  };

  // Reverse geocoding with Neshan (primary) and OSM fallback
  const reverseGeocode = async (lat, lng, isRetry = false) => {
    // Clear any existing timeouts
    if (geocodingTimeoutRef.current) {
      clearTimeout(geocodingTimeoutRef.current);
    }

    // Cancel any pending request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Create new abort controller
    abortControllerRef.current = new AbortController();

    // Reset error states
    setGeocodingError(false);
    setGeocodingTimeout(false);
    setIsGeocoding(true);
    setGeocodingApi("neshan");

    // Increment attempt counter if retry
    if (isRetry) {
      geocodingAttemptRef.current += 1;
      setRetryCount(geocodingAttemptRef.current);
    } else {
      geocodingAttemptRef.current = 0;
      setRetryCount(0);
    }

    // Set timeout - REDUCED FROM 15000ms to 5000ms for faster fallback
    geocodingTimeoutRef.current = setTimeout(() => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      setGeocodingTimeout(true);
      setGeocodingError(true);
      setIsGeocoding(false);
      
      // Use local fallback on timeout
      useLocalFallback(lat, lng);
      
      geocodingTimeoutRef.current = null;
    }, 5000); // Reduced from 15000 to 5000ms

    try {
      // Try Neshan API first
      try {
        const response = await axios.get(
          `https://api.neshan.org/v5/reverse`,
          {
            params: {
              lat: lat,
              lng: lng,
            },
            headers: {
              "Api-Key": NESHAN_API_KEY,
            },
            signal: abortControllerRef.current.signal,
            timeout: 3000, // Reduced from 8000 to 3000ms
          }
        );

        // Clear timeout on success
        if (geocodingTimeoutRef.current) {
          clearTimeout(geocodingTimeoutRef.current);
          geocodingTimeoutRef.current = null;
        }

        if (response.data) {
          // Handle Neshan response

          console.log('----------------- the nesahn response is --------------');

          console.log(response.data);
          const cleanAddress = formatNeshanAddress(response.data.formatted_address);

          // Extract city from city object or address
          let matchedCity = "";
          if (response.data.city) {
            matchedCity = matchCityFromApi(response.data.city.name || response.data.city);
          }
          if (!matchedCity) {
            matchedCity = extractCityFromNeshan(cleanAddress, response.data.city);
          }

          // Extract neighborhood
          let neighborhood = "";
          if (response.data.neighbourhood) {
            neighborhood = response.data.neighbourhood.name || response.data.neighbourhood;
          }
          if (!neighborhood) {
            neighborhood = extractNeighborhoodFromNeshan(cleanAddress, response.data.neighbourhood);
          }

          const state = response.data.state ? (response.data.state.name || response.data.state) : "";
          const municipality_zone = response.data.municipality_zone || "";

          set_addressCity(matchedCity || "");
          set_addressNeighbourhood(neighborhood);
          set_addressState(state);
          set_addressFormatted(cleanAddress);
          set_addressRegion(cleanAddress);
          set_addressMunicipality_zone(municipality_zone);

          // Reset touched states
          setTouched({
            city: false,
            neighborhood: false,
            address: false
          });

          setGeocodingError(false);
          setIsGeocoding(false);
          return;
        }
      } catch (neshanError) {
        console.log("Neshan reverse geocoding failed, trying OpenStreetMap...", neshanError);

        // Fallback to OpenStreetMap
        setGeocodingApi("osm");
        try {
          const response = await axios.get(
            `https://nominatim.openstreetmap.org/reverse`,
            {
              params: {
                format: "jsonv2",
                lat: lat,
                lon: lng,
                "accept-language": "fa-IR",
                zoom: 18,
              },
              headers: {
                "User-Agent": "AjurApp/1.0 (realestate@boomlex.ir)",
              },
              signal: abortControllerRef.current.signal,
              timeout: 3000, // Reduced from 10000 to 3000ms
            }
          );

          // Clear timeout on success
          if (geocodingTimeoutRef.current) {
            clearTimeout(geocodingTimeoutRef.current);
            geocodingTimeoutRef.current = null;
          }

          if (response.data) {
            // Create clean display name
            const cleanDisplayName = formatCleanAddress(response.data.display_name);

            if (response.data.address) {
              const addr = response.data.address;

              // Extract city from various possible fields
              const rawCity = addr.city ||
                addr.town ||
                addr.village ||
                addr.municipality ||
                addr.county ||
                "";

              // Match city with API data
              const matchedCity = matchCityFromApi(rawCity);

              // Extract neighborhood from various possible fields
              const rawNeighborhood = addr.neighbourhood ||
                addr.suburb ||
                addr.hamlet ||
                addr.locality ||
                addr.road ||
                "";

              const state = addr.state || addr.province || "";

              // Create formatted address from components (without postal code and country)
              const formattedParts = [];
              if (addr.amenity) formattedParts.push(addr.amenity);
              if (addr.road) formattedParts.push(addr.road);
              if (addr.neighbourhood) formattedParts.push(addr.neighbourhood);
              if (addr.suburb) formattedParts.push(addr.suburb);
              if (addr.city_district) formattedParts.push(addr.city_district);
              if (matchedCity) formattedParts.push(matchedCity);

              const formattedAddress = formattedParts.length > 0
                ? [...new Set(formattedParts)].join('، ')
                : cleanDisplayName;

              set_addressCity(matchedCity || rawCity);
              set_addressNeighbourhood(rawNeighborhood);
              set_addressState(state);
              set_addressFormatted(formattedAddress);
              set_addressRegion(formattedAddress);
              set_addressMunicipality_zone(addr.county || addr.district || "");

              // Reset touched states
              setTouched({
                city: false,
                neighborhood: false,
                address: false
              });
            }

            setGeocodingError(false);
            setIsGeocoding(false);
            return;
          }
        } catch (osmError) {
          console.error("OSM reverse geocoding error:", osmError);

          // Don't show error if it's an aborted request (from retry)
          if (osmError.name === 'CanceledError' || osmError.code === 'ERR_CANCELED') {
            return;
          }

          // Clear timeout
          if (geocodingTimeoutRef.current) {
            clearTimeout(geocodingTimeoutRef.current);
            geocodingTimeoutRef.current = null;
          }

          let errorMessage = "";
          let shouldRetry = false;

          // Determine error type
          if (osmError.code === 'ECONNABORTED' || osmError.message.includes('timeout')) {
            errorMessage = "دریافت اطلاعات زمان‌بر شد. از پایگاه داده محلی استفاده می‌شود.";
            setGeocodingTimeout(true);
            shouldRetry = geocodingAttemptRef.current < MAX_RETRY_ATTEMPTS;
          } else if (osmError.response && osmError.response.status === 429) {
            errorMessage = "تعداد درخواست‌ها زیاد است. از پایگاه داده محلی استفاده می‌شود.";
            setGeocodingTimeout(true);
            shouldRetry = geocodingAttemptRef.current < MAX_RETRY_ATTEMPTS;
          } else if (osmError.response && osmError.response.status >= 500) {
            errorMessage = "خطا در سرور. از پایگاه داده محلی استفاده می‌شود.";
            shouldRetry = geocodingAttemptRef.current < MAX_RETRY_ATTEMPTS;
          } else {
            errorMessage = "خطا در دریافت اطلاعات مکان. از پایگاه داده محلی استفاده می‌شود.";
            setGeocodingError(true);
          }

          // Handle retry
          if (shouldRetry) {
            setTimeout(() => {
              reverseGeocode(lat, lng, true);
            }, 2000);
          } else {
            if (geocodingAttemptRef.current >= MAX_RETRY_ATTEMPTS) {
              errorMessage = "دریافت اطلاعات پس از چند بار تلاش موفق نشد. از پایگاه داده محلی استفاده می‌شود.";
            }

            // Use local fallback when all APIs fail
            useLocalFallback(lat, lng);
            
            setProblem(errorMessage);
            set_alert_sevirity("warning"); // Changed from "error" to "warning"
            setOpenSnackBar(true);
            setGeocodingError(true);
            setIsGeocoding(false);
          }
        }
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);

      // Handle any other errors
      if (geocodingTimeoutRef.current) {
        clearTimeout(geocodingTimeoutRef.current);
        geocodingTimeoutRef.current = null;
      }

      // Use local fallback for any other errors
      useLocalFallback(lat, lng);
      
      setGeocodingError(true);
      setProblem("خطا در دریافت اطلاعات مکان. از پایگاه داده محلی استفاده می‌شود.");
      set_alert_sevirity("warning"); // Changed from "error" to "warning"
      setOpenSnackBar(true);
      setIsGeocoding(false);
    } finally {
      if (!geocodingTimeoutRef.current) {
        setIsGeocoding(false);
      }
    }
  };

  // Local fallback function for when APIs are blocked or fail
  const useLocalFallback = (lat, lng) => {
    // Find nearest city from local database
    const nearestCity = IRANIAN_CITIES.reduce((prev, curr) => {
      const prevDist = Math.sqrt(
        Math.pow(prev.lat - lat, 2) + Math.pow(prev.lng - lng, 2)
      );
      const currDist = Math.sqrt(
        Math.pow(curr.lat - lat, 2) + Math.pow(curr.lng - lng, 2)
      );
      return prevDist < currDist ? prev : curr;
    });
    
    // Find nearest neighborhood for Tehran
    let nearestNeighborhood = null;
    if (Math.abs(lat - 35.6892) < 0.5 && Math.abs(lng - 51.3890) < 0.5) {
      nearestNeighborhood = TEHRAN_NEIGHBORHOODS.reduce((prev, curr) => {
        const prevDist = Math.sqrt(
          Math.pow(prev.lat - lat, 2) + Math.pow(prev.lng - lng, 2)
        );
        const currDist = Math.sqrt(
          Math.pow(curr.lat - lat, 2) + Math.pow(curr.lng - lng, 2)
        );
        return prevDist < currDist ? prev : curr;
      });
    }
    
    // Update state with local data
    set_addressCity(nearestCity.name);
    set_addressState(nearestCity.province);
    if (nearestNeighborhood) {
      set_addressNeighbourhood(nearestNeighborhood.name);
    } else {
      set_addressNeighbourhood("");
    }
    set_addressFormatted(`آدرس تقریبی: ${nearestCity.name}${nearestNeighborhood ? `، ${nearestNeighborhood.name}` : ''}`);
    set_addressRegion(`آدرس تقریبی: ${nearestCity.name}${nearestNeighborhood ? `، ${nearestNeighborhood.name}` : ''}`);
    set_addressMunicipality_zone("");
    
    // Reset touched states
    setTouched({
      city: false,
      neighborhood: false,
      address: false
    });
  };


  // Component to handle map center and update on move with pin animation
  // Component to handle map center and update on move with pin animation
  const MapCenterHandler = () => {
    const map = useMapEvents({
      movestart: () => {
        // Pin grows and shadow becomes bigger when map starts moving
        setIsMapMoving(true);
        setPinScale(1.3);

        // Clear any existing timeout
        if (moveTimeoutRef.current) {
          clearTimeout(moveTimeoutRef.current);
        }
      },
      move: () => {
        // Pin stays big while moving
        setIsMapMoving(true);
        setPinScale(1.3);
      },
      moveend: () => {
        const center = map.getCenter();
        setSelectedPosition([center.lat, center.lng]);
        set_final_lat(center.lat);
        set_final_lng(center.lng);
        set_isSelected(true);

        // Set timeout to return pin to normal after a short delay
        moveTimeoutRef.current = setTimeout(() => {
          setPinScale(1);
          setIsMapMoving(false);
        }, 300);

        // Reverse geocode the new center
        reverseGeocode(center.lat, center.lng);
      },
      zoomend: () => {
        set_zoomLevel(map.getZoom());
      }
    });

    // Store map reference
    mapRef.current = map;

    return null;
  };

  // Center Pin Marker with animation
  // Center Pin Marker with clear shadow below
  const CenterPin = () => {
    return (
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        zIndex: 1000,
        pointerEvents: 'none',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
      }}>
        {/* The pin icon */}
        <div style={{
          transform: `scale(${pinScale})`,
          transition: 'transform 0.2s ease-out',
          zIndex: 2,
          marginBottom: isMapMoving ? '5px' : '0',
        }}>
          <RoomIcon sx={{
            fontSize: 48,
            color: '#ff5252',
          }} />
        </div>

        {/* Shadow below the pin */}
        <div style={{
          width: isMapMoving ? '45px' : '28px',
          height: isMapMoving ? '16px' : '10px',
          borderRadius: '50%',
          background: isMapMoving ? 'rgba(0,0,0,0.7)' : 'rgba(0,0,0,0.3)',
          filter: isMapMoving ? 'blur(4px)' : 'blur(2px)',
          transition: 'all 0.2s ease-out',
          marginTop: isMapMoving ? '-15px' : '-10px',
          boxShadow: isMapMoving ? '0 4px 8px rgba(0,0,0,0.3)' : 'none',
        }} />
      </div>
    );
  };

  // Handle confirmation button click
  const handleConfirmLocation = () => {
    setShowConfirmationModal(true);
  };

  // Handle modal close
  const handleModalClose = () => {
    setShowConfirmationModal(false);
  };

  // Handle final submission
  // Handle final submission
const handleFinalSubmit = () => {
  // Validate all fields
  const cityError = !addressCity || addressCity.trim() === '';
  const neighborhoodError = !addressNeighbourhood || 
    addressNeighbourhood.trim() === '' || 
    !filteredNeighborhoods.some(nb => nb.name === addressNeighbourhood);
  const addressError = !addressFormatted || addressFormatted.trim() === '';

  // Update validation errors
  setValidationErrors({
    city: cityError,
    neighborhood: neighborhoodError,
    address: addressError
  });

  // Mark all fields as touched
  setTouched({
    city: true,
    neighborhood: true,
    address: true
  });

  if (!isSelected) {
    setProblem("لطفا ابتدا موقعیت ملک را مشخص کنید");
    set_alert_sevirity("warning");
    setOpenSnackBar(true);
    return;
  }

  if (cityError) {
    setProblem("لطفا شهر را انتخاب کنید");
    set_alert_sevirity("warning");
    setOpenSnackBar(true);
    return;
  } else if (neighborhoodError) {
    setProblem("لطفا محله را انتخاب کنید");
    set_alert_sevirity("warning");
    setOpenSnackBar(true);
    return;
  } else if (addressError) {
    setProblem("لطفا آدرس را پر کنید");
    set_alert_sevirity("warning");
    setOpenSnackBar(true);
    return;
  }

  set_btn_status(true);
  setProblem(""); // Clear any previous error messages
  
  var token = Cookies.get("id_token");

  axios({
    method: "post",
    url: "https://api.boomlex.ir/api/post-model-location",
    timeout: 1000 * 35,
    params: {
      token: token,
      lat: final_lat,
      long: final_lng,
      worker_id: returnedWorker.id,
      region: addressRegion,
      neighbourhood: addressNeighbourhood,
      city: addressCity,
      municipality_zone: addressMunicipality_zone,
      state: addressState,
      formatted: addressFormatted,
    },
  })
    .then((response) => {
      if (response.data.status == "200") {

        props.onSuccess(); 
        set_alert_sevirity("success");
        setProblem("آگهی شما با موفقیت ثبت شد");
        setOpenSnackBar(true);
        
        // Close modal after success
        setTimeout(() => {
          setShowConfirmationModal(false);
          router.push(`/panel/upgrade/${returnedWorker.id}`);   
        }, 1000);
        
        set_btn_status(false);
      } else {
        set_alert_sevirity("error");
        setProblem("متاسفانه با مشکلی مواجه شدیم");
        set_btn_status(false);
        setOpenSnackBar(true);
      }
    })
    .catch((e) => {
      console.error("Submission error:", e);
      set_alert_sevirity("error");
      
      // More specific error messages
      if (e.code === 'ECONNABORTED') {
        setProblem("ارسال اطلاعات زمان‌بر شد. لطفا مجدد تلاش کنید.");
      } else if (e.response && e.response.status === 500) {
        setProblem("خطای سرور. لطفا چند لحظه دیگر تلاش کنید.");
      } else {
        setProblem("خطا در ارتباط با سرور. لطفا مجدد تلاش کنید.");
      }
      
      setOpenSnackBar(true);
      set_btn_status(false);
    });
};

  // Function to check geolocation permission
  const checkGeolocationPermission = async () => {
    if (navigator.permissions && navigator.permissions.query) {
      try {
        const result = await navigator.permissions.query({ name: 'geolocation' });

        if (result.state === 'denied') {
          setShowPermissionDialog(true);
          return false;
        }
      } catch (error) {
        console.error("Error checking permission:", error);
      }
    }
    return true;
  };

  // Function to get current location with proper error handling
  const getCurrentLocation = () => {
    // First check if geolocation is supported
    if (!navigator.geolocation) {
      setProblem("مرورگر شما از موقعیت مکانی پشتیبانی نمی‌کند");
      set_alert_sevirity("warning");
      setOpenSnackBar(true);
      return;
    }

    // Check permission first
    checkGeolocationPermission().then((hasPermission) => {
      if (!hasPermission) return;

      // Set loading state
      setIsGeocoding(true);
      setGeocodingApi("neshan");
      setProblem("در حال دریافت موقعیت مکانی...");
      set_alert_sevirity("info");
      setOpenSnackBar(true);

      // Options for geolocation
      const options = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      };

      // Success callback
      const successCallback = (position) => {
        const { latitude, longitude } = position.coords;

        setSelectedPosition([latitude, longitude]);
        set_final_lat(latitude);
        set_final_lng(longitude);
        set_isSelected(true);

        // Close the loading message
        setOpenSnackBar(false);

        // Reverse geocode the location
        reverseGeocode(latitude, longitude);

        // Fly to the location on map
        if (mapRef.current) {
          mapRef.current.flyTo([latitude, longitude], 17, {
            duration: 2
          });
        }
      };

      // Error callback with detailed messages
      const errorCallback = (error) => {
        setIsGeocoding(false);

        let errorMessage = "";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "دسترسی به موقعیت مکانی رد شد. لطفا از تنظیمات مرورگر دسترسی را فعال کنید";
            setShowPermissionDialog(true);
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "اطلاعات موقعیت مکانی در دسترس نیست";
            break;
          case error.TIMEOUT:
            errorMessage = "زمان دریافت موقعیت مکانی به پایان رسید";
            break;
          default:
            errorMessage = "خطا در دریافت موقعیت مکانی";
            break;
        }

        setProblem(errorMessage);
        set_alert_sevirity("error");
        setOpenSnackBar(true);

        console.error("Geolocation error:", error);
      };

      // Request location
      navigator.geolocation.getCurrentPosition(
        successCallback,
        errorCallback,
        options
      );
    });
  };

  // Your existing useEffect hooks
  useEffect(() => {
    if (edit_id) {
      fetch_old_locations_params();
      setCurrentStep(1);
    }
  }, [edit_id]);

  useEffect(() => {
    console.log("the returned worker id is");
    console.log(returnedWorker.id);

    var selected_city_lat = Cookies.get("selected_city_lat");
    var selected_city_lng = Cookies.get("selected_city_lng");

    if (!edit_id) {
      if (selected_city_lat) {
        set_city_lat(selected_city_lat);
      } else {
        set_city_lat(35.6892);
        var selected_city_lat = "35.6892";
      }

      if (selected_city_lng) {
        set_city_lng(selected_city_lng);
      } else {
        set_city_lng(51.3890);
        var selected_city_lng = "51.3890";
      }

      setSelectedPosition([selected_city_lat, selected_city_lng]);
      // Reverse geocode the default location
      reverseGeocode(parseFloat(selected_city_lat), parseFloat(selected_city_lng));
    }

    axios({
      method: "get",
      url: "https://api.boomlex.ir/api/all-available-locations",
      timeout: 1000 * 35,
      params: {},
    })
      .then((response) => {
        set_available_cities(response.data.cities);
        set_available_neighborhoods(response.data.neighborhoods);
      })
      .catch((e) => {
        console.log("error when try to fetch available data from api--------");
      });
  }, []);

  const fetch_old_locations_params = (worker) => {
    axios({
      method: "get",
      url: `https://api.boomlex.ir/api/posts/${edit_id}`,
    }).then(function (response) {
      set_final_lat(response.data.details.lat);
      set_final_lng(response.data.details.long);
      set_addressFormatted(response.data.details.formatted);
      set_addressCity(response.data.details.city);
      set_addressNeighbourhood(response.data.details.neighbourhood);
      set_city_lat(response.data.details.lat);
      set_city_lng(response.data.details.long);
      setSelectedPosition([
        response.data.details.lat,
        response.data.details.long,
      ]);
      set_isSelected(true);

      // Reverse geocode to get address
      reverseGeocode(response.data.details.lat, response.data.details.long);
    });
  };

  // Enhanced loading spinner component with error handling
  const renderLoadingSpinner = () => {
    if (!isGeocoding) return null;

    return (
      <Box
        sx={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "rgba(0, 0, 0, 0.5)",
          zIndex: 2000,
        }}
      >
        <Box
          sx={{
            backgroundColor: "white",
            padding: 4,
            borderRadius: 3,
            textAlign: "center",
            maxWidth: 400,
            width: "90%",
          }}
        >
          {!geocodingError ? (
            <>
              <LinearProgress sx={{ width: "100%", mb: 2 }} />
              <Typography variant="body1" color="textSecondary" gutterBottom>
                {geocodingTimeout
                  ? "دریافت اطلاعات بیشتر از حد معمول زمان می‌برد..."
                  : retryCount > 0
                    ? `تلاش مجدد (${retryCount}/${MAX_RETRY_ATTEMPTS})...`
                    : "در حال دریافت اطلاعات مکان..."}
              </Typography>
              {retryCount > 0 && (
                <Typography variant="caption" color="textSecondary">
                  {retryCount === 1 ? "تلاش دوم" : "تلاش نهایی"}
                </Typography>
              )}
              <Chip
                label={geocodingApi === "neshan" ? "نشان" : "OpenStreetMap"}
                size="small"
                sx={{ mt: 1, bgcolor: '#f0f0f0' }}
              />
            </>
          ) : (
              <>
                <ErrorOutlineIcon
                  color="error"
                  sx={{ fontSize: 60, mb: 2 }}
                />
                <Typography variant="h6" color="error" gutterBottom>
                  خطا در دریافت اطلاعات
              </Typography>
                <Typography variant="body2" color="textSecondary" sx={{ mb: 3 }}>
                  {geocodingTimeout
                    ? "دریافت اطلاعات زمان‌بر شد. لطفا دوباره تلاش کنید یا موقعیت را به صورت دستی وارد کنید."
                    : "مشکلی در دریافت اطلاعات پیش آمد. لطفا دوباره تلاش کنید."}
                </Typography>
                <Box sx={{ display: "flex", gap: 1, justifyContent: "center" }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => reverseGeocode(final_lat, final_lng, true)}
                    startIcon={<RefreshIcon />}
                  >
                    تلاش مجدد
                </Button>
                  <Button
                    variant="outlined"
                    onClick={() => {
                      setIsGeocoding(false);
                      setGeocodingError(false);
                    }}
                  >
                    بستن
                </Button>
                </Box>
              </>
            )}
        </Box>
      </Box>
    );
  };

  // Search component for places (top bar)
  const renderPlaceSearch = () => {
    return (
      <Box sx={{
        position: "absolute",
        top: 16,
        left: 16,
        right: 16,
        zIndex: 1000,
      }}>
        <Autocomplete
          freeSolo
          options={searchResults}
          getOptionLabel={(option) => option.clean_display_name || option.display_name || ""}
          loading={isSearching}
          onInputChange={(event, newValue) => {
            setPlaceSearchQuery(newValue);
            if (newValue.length >= 3) {
              const timeoutId = setTimeout(() => {
                searchPlaces(newValue);
              }, 3000);
              return () => clearTimeout(timeoutId);
            } else {
              setSearchResults([]);
            }
          }}
          onChange={(event, newValue) => {
            if (newValue) {
              handlePlaceSelect(newValue);
            }
          }}
          renderInput={(params) => (
            <TextField
              {...params}
              placeholder="جستجوی مکان (رباط کریم، تهران و...)"
              variant="outlined"
              // fullWidth
              sx={{
                backgroundColor: "white",
                borderRadius: 3,
                '& .MuiOutlinedInput-root': {
                  borderRadius: 3,
                  pr: 1,
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                }
              }}
              InputProps={{
                ...params.InputProps,
                startAdornment: (
                  <SearchIcon sx={{ color: '#999', ml: 1, mr: 0.5 }} />
                ),
                endAdornment: (
                  <React.Fragment>
                    {isSearching ? (
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <LinearProgress sx={{ width: 20, height: 20, m: 1 }} />
                        <Chip
                          label={searchApi === "neshan" ? "نشان" : "OSM"}
                          size="small"
                          sx={{ height: 20, fontSize: '0.7rem' }}
                        />
                      </Box>
                    ) : null}
                    {params.InputProps.endAdornment}
                  </React.Fragment>
                ),
              }}
            />
          )}
          noOptionsText={
            placeSearchQuery.length >= 3
              ? "مکانی یافت نشد"
              : "حداقل ۳ حرف تایپ کنید"
          }
          popupIcon={null}
          renderOption={(props, option) => (
            <li {...props}>
              <Box>
                <Typography variant="body2" fontWeight="bold">
                  {option.clean_display_name?.split('،')[0] || option.display_name?.split(',')[0]}
                </Typography>
                <Typography variant="caption" color="textSecondary">
                  {option.clean_display_name?.split('،').slice(1).join('،').trim() ||
                    option.display_name?.split(',').slice(1).join(',').trim()}
                </Typography>
                <Chip
                  label={option.source === "neshan" ? "نشان" : "OSM"}
                  size="small"
                  sx={{ height: 16, fontSize: '0.6rem', mt: 0.5 }}
                />
              </Box>
            </li>
          )}
        />
      </Box>
    );
  };

  // Footer with location info and confirm button
  const renderFooter = () => {
    return (
      <Paper
        elevation={8}
        sx={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          height: "20%",
          minHeight: 140,
          backgroundColor: "white",
          borderTopLeftRadius: 24,
          borderTopRightRadius: 24,
          zIndex: 1000,
          display: "flex",
          flexDirection: "column",
          p: 2,
        }}
      >
        {/* Top section with location title and search icon */}
        <Box sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          mb: 1.5
        }}>
          <Box sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            flex: 1,
            ml: 1
          }}>
            <LocationOnIcon sx={{ color: '#ff5252', fontSize: 20 }} />
            {isGeocoding ? (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <LinearProgress size={20} sx={{ width: 20, height: 20 }} />
                <Typography variant="body2" color="textSecondary">
                  در حال دریافت اطلاعات مکان...
                </Typography>
                <Chip
                  label={geocodingApi === "neshan" ? "نشان" : "OSM"}
                  size="small"
                  sx={{ height: 20, fontSize: '0.7rem' }}
                />
              </Box>
            ) : (
                <Typography
                  variant="body2"
                  color="textSecondary"
                  sx={{
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    maxWidth: "70%"
                  }}
                >
                  {addressFormatted || "موقعیت مکانی را انتخاب کنید"}
                </Typography>
              )}
          </Box>
          <IconButton
            size="small"
            sx={{
              backgroundColor: '#f5f5f5',
              '&:hover': { backgroundColor: '#e0e0e0' }
            }}
            onClick={getCurrentLocation}
          >
            <MyLocationIcon sx={{ fontSize: 20, color: '#666' }} />
          </IconButton>
        </Box>

        {/* Bottom section with confirm button */}
        <Box sx={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          justifyContent: "center"
        }}>
          <Button
            variant="contained"
            fullWidth
            disabled={!isSelected || isGeocoding}
            onClick={handleConfirmLocation}
            sx={{
              py: 1.5,
              borderRadius: 3,
              fontSize: "1.1rem",
              fontWeight: 600,
              backgroundColor: "#4CAF50",
              background: "linear-gradient(135deg, #4CAF50 0%, #45a049 100%)",
              color: "white",
              textTransform: "none",
              boxShadow: "0 4px 15px rgba(76, 175, 80, 0.3)",
              '&:hover': {
                background: "linear-gradient(135deg, #45a049 0%, #3d8b40 100%)",
                transform: "translateY(-2px)",
                boxShadow: "0 6px 20px rgba(76, 175, 80, 0.4)",
              },
              '&.Mui-disabled': {
                background: "linear-gradient(135deg, #d0d0d0 0%, #b8b8b8 100%)",
                color: "white",
              }
            }}
          >
            {isGeocoding ? "در حال دریافت اطلاعات..." : "تایید موقعیت"}
          </Button>
        </Box>
      </Paper>
    );
  };

  // Confirmation Modal with city, neighborhood, and address fields
  // Confirmation Modal with city, neighborhood, and address fields
const renderConfirmationModal = () => {
  const isFormValid = !validationErrors.city && !validationErrors.neighborhood && !validationErrors.address;

  return (
    <Modal
      open={showConfirmationModal}
      onClose={handleModalClose}
      aria-labelledby="confirmation-modal"
      closeAfterTransition
    >
      <Fade in={showConfirmationModal}>
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '90%',
          maxWidth: 500,
          bgcolor: 'background.paper',
          borderRadius: 4,
          boxShadow: 24,
          p: 3,
          maxHeight: '90vh',
          overflow: 'auto'
        }}>
          {/* Modal Header */}
          <Box sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            mb: 2,
            pb: 1,
            borderBottom: '1px solid #eee'
          }}>
            <Typography variant="h6" sx={{ fontWeight: 600, color: '#333' }}>
              اطلاعات تکمیلی موقعیت
            </Typography>
            <IconButton onClick={handleModalClose} size="small">
              <CloseIcon />
            </IconButton>
          </Box>

          {/* Location Preview */}
          <Box sx={{
            bgcolor: '#f8f9fa',
            p: 2,
            borderRadius: 3,
            mb: 3,
            display: 'flex',
            alignItems: 'center',
            gap: 1
          }}>
            <LocationOnIcon sx={{ color: '#ff5252' }} />
            <Typography variant="body2" color="textSecondary">
              {addressFormatted || "موقعیت انتخاب شده"}
            </Typography>
          </Box>

          {/* Form Fields */}
          <Box sx={{ mb: 3 }}>
            {/* City Selection */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" sx={{ mb: 1, fontWeight: 500, color: '#555' }}>
                شهر <span style={{ color: '#ff5252' }}>*</span>
              </Typography>
              <FormControl fullWidth error={touched.city && validationErrors.city}>
                <Autocomplete
                  options={filteredCities}
                  getOptionLabel={(option) => option.title || ""}
                  value={available_cities.find(city => city.title === addressCity) || null}
                  onChange={(event, newValue) => {
                    set_addressCity(newValue?.title || "");
                    setCitySearch("");
                    set_addressNeighbourhood("");
                    setNeighborhoodSearch("");
                    if (touched.city) {
                      setTouched(prev => ({ ...prev, city: true }));
                    }
                  }}
                  inputValue={citySearch}
                  onInputChange={(event, newInputValue) => {
                    setCitySearch(newInputValue);
                  }}
                  onBlur={() => handleFieldBlur('city')}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder="انتخاب شهر"
                      variant="outlined"
                      error={touched.city && validationErrors.city}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          borderRadius: 2,
                          bgcolor: '#f5f5f5',
                        }
                      }}
                    />
                  )}
                />
                {touched.city && validationErrors.city && (
                  <FormHelperText error>شهر باید انتخاب شود</FormHelperText>
                )}
              </FormControl>
            </Box>

            {/* Neighborhood Selection */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" sx={{ mb: 1, fontWeight: 500, color: '#555' }}>
                محله <span style={{ color: '#ff5252' }}>*</span>
              </Typography>
              <FormControl fullWidth disabled={!addressCity} error={touched.neighborhood && validationErrors.neighborhood}>
                <Autocomplete
                  options={filteredNeighborhoods}
                  getOptionLabel={(option) => option.name || ""}
                  value={filteredNeighborhoods.find(nb => nb.name === addressNeighbourhood) || null}
                  onChange={(event, newValue) => {
                    if (newValue) {
                      set_addressNeighbourhood(newValue.name);
                    } else {
                      set_addressNeighbourhood("");
                    }
                    setNeighborhoodSearch("");
                    if (touched.neighborhood) {
                      setTouched(prev => ({ ...prev, neighborhood: true }));
                    }
                  }}
                  inputValue={neighborhoodSearch}
                  onInputChange={(event, newInputValue) => {
                    setNeighborhoodSearch(newInputValue);
                  }}
                  onBlur={() => handleFieldBlur('neighborhood')}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      placeholder={addressCity ? "انتخاب محله" : "ابتدا شهر را انتخاب کنید"}
                      variant="outlined"
                      error={touched.neighborhood && validationErrors.neighborhood}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          borderRadius: 2,
                          bgcolor: '#f5f5f5',
                        }
                      }}
                    />
                  )}
                  isOptionEqualToValue={(option, value) => option.name === value.name}
                  filterOptions={(options, { inputValue }) => {
                    // Filter the options based on input
                    return options.filter(option =>
                      option.name?.toLowerCase().includes(inputValue.toLowerCase())
                    );
                  }}
                  noOptionsText="محله‌ای یافت نشد"
                />
                {touched.neighborhood && validationErrors.neighborhood && (
                  <FormHelperText error>محله باید انتخاب شود</FormHelperText>
                )}
              </FormControl>
            </Box>

            {/* Address Field */}
            <Box sx={{ mb: 2 }}>
              <Typography variant="body2" sx={{ mb: 1, fontWeight: 500, color: '#555' }}>
                 ( قابل ویرایش ) آدرس کامل <span style={{ color: '#ff5252' }}>*</span>
              </Typography>
              <TextField
                fullWidth
                multiline
                rows={3}
                placeholder="آدرس کامل ملک را وارد کنید"
                value={addressFormatted}
                onChange={(e) => set_addressFormatted(e.target.value)}
                onBlur={() => handleFieldBlur('address')}
                error={touched.address && validationErrors.address}
                helperText={touched.address && validationErrors.address ? "آدرس باید پر شود" : ""}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    borderRadius: 2,
                    bgcolor: '#f5f5f5',
                  }
                }}
              />
            </Box>
          </Box>

          {/* Status Messages */}
          {problem && alert_sevirity === 'success' && (
            <Box sx={{ 
              mb: 2, 
              p: 2, 
              bgcolor: '#e8f5e8', 
              borderRadius: 2,
              display: 'flex',
              alignItems: 'center',
              gap: 1
            }}>
              <CheckCircleIcon sx={{ color: '#4CAF50' }} />
              <Typography variant="body2" sx={{ color: '#2e7d32' }}>
                {problem}
              </Typography>
            </Box>
          )}

          {problem && alert_sevirity === 'error' && (
            <Box sx={{ 
              mb: 2, 
              p: 2, 
              bgcolor: '#ffebee', 
              borderRadius: 2,
              display: 'flex',
              alignItems: 'center',
              gap: 1
            }}>
              <WarningIcon sx={{ color: '#f44336' }} />
              <Typography variant="body2" sx={{ color: '#c62828' }}>
                {problem}
              </Typography>
            </Box>
          )}

          {/* Action Buttons */}
          <Box sx={{ display: 'flex', gap: 1, mt: 2 }}>
            <Button
              variant="outlined"
              fullWidth
              onClick={handleModalClose}
              disabled={btn_status}
              sx={{
                py: 1.5,
                borderRadius: 3,
                borderColor: '#999',
                color: '#666',
                '&:hover': {
                  borderColor: '#ff5252',
                  color: '#ff5252',
                },
                '&.Mui-disabled': {
                  borderColor: '#ddd',
                  color: '#aaa',
                }
              }}
            >
              انصراف
            </Button>
            
            {alert_sevirity === 'error' && problem ? (
              <Button
                variant="contained"
                fullWidth
                onClick={handleFinalSubmit}
                disabled={!isFormValid || btn_status}
                sx={{
                  py: 1.5,
                  borderRadius: 3,
                  fontSize: '1rem',
                  fontWeight: 600,
                  background: 'linear-gradient(135deg, #ff9800 0%, #f57c00 100%)',
                  color: 'white',
                  textTransform: 'none',
                  '&:hover': {
                    background: 'linear-gradient(135deg, #f57c00 0%, #ef6c00 100%)',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 6px 20px rgba(255, 152, 0, 0.4)',
                  },
                  '&.Mui-disabled': {
                    background: 'linear-gradient(135deg, #d0d0d0 0%, #b8b8b8 100%)',
                  }
                }}
              >
                تلاش مجدد
              </Button>
            ) : (
              <Button
                variant="contained"
                fullWidth
                disabled={!isFormValid || btn_status}
                onClick={handleFinalSubmit}
                sx={{
                  py: 1.5,
                  borderRadius: 3,
                  fontSize: '1rem',
                  fontWeight: 600,
                  background: btn_status 
                    ? 'linear-gradient(135deg, #4a90e2 0%, #357abd 100%)'
                    : 'linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%)',
                  color: 'white',
                  textTransform: 'none',
                  position: 'relative',
                  '&:hover': btn_status ? {} : {
                    background: 'linear-gradient(135deg, #ff5252 0%, #ff3838 100%)',
                    transform: 'translateY(-2px)',
                    boxShadow: '0 6px 20px rgba(255, 107, 107, 0.4)',
                  },
                  '&.Mui-disabled': {
                    background: 'linear-gradient(135deg, #d0d0d0 0%, #b8b8b8 100%)',
                  }
                }}
              >
                {btn_status ? (
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Box component="span" sx={{ 
                      width: 20, 
                      height: 20, 
                      borderRadius: '50%', 
                      border: '2px solid rgba(255,255,255,0.3)',
                      borderTopColor: 'white',
                      animation: 'spin 1s linear infinite',
                      '@keyframes spin': {
                        '0%': { transform: 'rotate(0deg)' },
                        '100%': { transform: 'rotate(360deg)' }
                      }
                    }} />
                    در حال ارسال...
                  </Box>
                ) : (
                  "تایید نهایی"
                )}
              </Button>
            )}
          </Box>
        </Box>
      </Fade>
    </Modal>
  );
};

  const handleCloseSnackBar = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenSnackBar(false);
  };

  return city_lat ? (
    <div style={{
      position: "relative",
      height: "70vh",
      width: "100%",
      overflow: "hidden",
      borderRadius: "24px"
    }}>
      {/* Map Container */}
      <MapContainer
        className={Styles["location"]}
        center={selectedPosition}
        zoom={zoomLevel}
        scrollWheelZoom={true}
        style={{
          height: "100%",
          width: "100%",
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0
        }}
        whenCreated={(map) => {
          mapRef.current = map;
          // Force a resize after map is created
          setTimeout(() => {
            map.invalidateSize();
          }, 100);
        }}
      >
        <MapCenterHandler />
        <LayersControl position="topright">
          <LayersControl.BaseLayer checked name="نقشه عادی">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
          <LayersControl.BaseLayer name="نقشه سیاه و سفید">
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png"
            />
          </LayersControl.BaseLayer>
        </LayersControl>
      </MapContainer>

      {/* Center Pin with Animation */}
      <CenterPin />

      {/* Search Bar */}
      {renderPlaceSearch()}

      {/* Footer */}
      {renderFooter()}

      {/* Confirmation Modal */}
      {renderConfirmationModal()}

      {/* Permission Dialog */}
      <PermissionDialog
        open={showPermissionDialog}
        onClose={() => setShowPermissionDialog(false)}
      />

      {/* Loading Spinner */}
      {/* {renderLoadingSpinner()} */}

      {/* Snackbar for notifications */}
      <Snackbar
        open={openSnackBar}
        autoHideDuration={6000}
        onClose={handleCloseSnackBar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert
          onClose={handleCloseSnackBar}
          severity={alert_sevirity}
          sx={{ width: "100%" }}
        >
          {problem}
        </Alert>
      </Snackbar>
    </div>
  ) : null;
}

export default LocationForm;