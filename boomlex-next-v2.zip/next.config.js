/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  experimental: {
    optimizePackageImports: [
      'lucide-react',
      '@mui/material',
      '@mui/icons-material',
      '@mui/lab',
      '@mui/system',
      '@mui/styles',
      '@mui/x-date-pickers',
      'react-icons',
      'date-fns',
      'recharts',
      'react-spinners',
      'react-spinners-kit',
      'react-bootstrap',
      '@react-three/drei',
    ],
  },

  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'api.boomlex.ir',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'www.api.boomlex.ir',
        pathname: '/**',
      },
      {
        protocol: 'http',
        hostname: 'localhost',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'http',
        hostname: '127.0.0.1',
        port: '',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'via.placeholder.com',
        pathname: '/**',
      },
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        pathname: '/**',
      },
    ],
  },

  trailingSlash: false,

  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
        ],
      },
    ];
  },

  async redirects() {
    return [];
  },
};

module.exports = nextConfig;