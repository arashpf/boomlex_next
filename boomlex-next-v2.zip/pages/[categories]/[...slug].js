import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
  useLayoutEffect,
} from "react";
import PropTypes from "prop-types";
import { useRouter } from "next/router";
import Head from "next/head";
import Script from "next/script";
import Image from "next/image";
import Styles from "../../styles/CategoriesWorkersIndex.module.css";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import WorkerCard from "../../components/cards/WorkerCard";
import Link from "next/link";
import FilterComponent from "../../components/filter/FilterComponent";
import { useMediaQuery, useTheme } from "@mui/material";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import HomeIcon from "@mui/icons-material/Home";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CategoryIcon from "@mui/icons-material/Category";
import Alert from "@mui/material/Alert";
import Skeleton from "@mui/material/Skeleton";
import axios from "axios";
import dynamic from "next/dynamic";
import { getPersianCityName } from "../../components/util/cityNames";
import { buildClientContext, fireSsrEvent } from "../../lib/ssrTrack";
import { trackEvent } from "../../lib/track";
import { isTrackingParam } from "../../lib/skipTrackingParams";

const FileRequest = dynamic(() => import("../../components/request/FileRequest"), {
  ssr: false,
  loading: () => <div className="section-skeleton" />,
});

const MemoizedWorkerCard = React.memo(WorkerCard);

const CardSkeleton = () => (
  <Grid item xs={12} sm={6} md={4}>
    <Skeleton
      variant="rectangular"
      height={200}
      sx={{ borderRadius: 2, mb: 1 }}
    />
    <Skeleton variant="text" sx={{ fontSize: "1rem" }} />
    <Skeleton variant="text" sx={{ fontSize: "1rem", width: "60%" }} />
  </Grid>
);

function normalizePriceToIRR(price) {
  if (!price) return null;
  const n = String(price).replace(/[^0-9]/g, "");
  return n ? String(Number(n) * 10) : null;
}

function getSingleParam(value) {
  if (Array.isArray(value)) return value[0] || "";
  return value || "";
}

function getSlugArray(slug) {
  if (Array.isArray(slug)) return slug;
  if (slug) return [slug];
  return [];
}

function isMultiNeighborhoodValue(value) {
  return String(value || "").includes(",");
}

function cleanRouterQuery(query = {}) {
  const cleaned = { ...query };
  delete cleaned.categories;
  delete cleaned.slug;
  return cleaned;
}

function findNeighborhoodBySlugOrId(neighborhoods, value) {
  if (!value || !Array.isArray(neighborhoods)) return null;
  const stringValue = String(value);

  if (stringValue.includes(",")) return null;

  return (
    neighborhoods.find((item) => {
      return (
        String(item?.id) === stringValue ||
        String(item?.eng_name || "") === stringValue ||
        String(item?.slug || "") === stringValue ||
        String(item?.value || "") === stringValue ||
        String(item?.name || "") === stringValue ||
        String(item?.title || "") === stringValue
      );
    }) || null
  );
}

function getNeighborhoodDisplayName(neighborhoods, value) {
  const found = findNeighborhoodBySlugOrId(neighborhoods, value);
  return found?.name || found?.title || "";
}

function buildWorkersApiUrl({
  catname,
  city,
  page = 1,
  per_page = 10,
  query = {},
  finalNeighborhoodId = "",
}) {
  let apiUrl = `https://api.boomlex.ir/api/server-filtered-workers?catname=${encodeURIComponent(
    catname
  )}&city=${encodeURIComponent(city)}&page=${page}&per_page=${per_page}`;

  if (query.categoryId) {
    apiUrl += `&category_id=${encodeURIComponent(getSingleParam(query.categoryId))}`;
  }

  if (query.features) {
    apiUrl += `&features=${encodeURIComponent(getSingleParam(query.features))}`;
  }

  if (finalNeighborhoodId) {
    apiUrl += `&neighborhoods=${encodeURIComponent(finalNeighborhoodId)}`;
  }

  Object.keys(query).forEach((key) => {
    if (isTrackingParam(key)) return; 
    if (key.includes("_min") || key.includes("_max")) {
      apiUrl += `&${key}=${encodeURIComponent(getSingleParam(query[key]))}`;
    }
  });

  if (query.sortBy && query.sortBy !== "newest") {
    const sortMap = {
      newest: "created_at_desc",
      oldest: "created_at_asc",
      most_viewed: "total_view_desc",
    };

    const [field, order] = sortMap[query.sortBy]?.split("_") || [
      "created_at",
      "desc",
    ];

    apiUrl += `&sort_by=${field}&sort_order=${order}`;
  }

  const skipKeys = new Set([
    "categories",
    "slug",
    "city",
    "catname",
    "page",
    "per_page",
    "categoryId",
    "category_id",
    "features",
    "neighborhoods",
    "sortBy",
    "sort_by",
    "sort_order",
  ]);

  Object.keys(query).forEach((key) => {
    if (skipKeys.has(key)) return;
    if (isTrackingParam(key)) return; 
    const rawValue = query[key];
    const value = Array.isArray(rawValue) ? rawValue[0] : rawValue;
    if (value === undefined || value === null || value === "") return;
    apiUrl += `&${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
  });

  return apiUrl;
}

// ─── NEW: build a clean filters object from URL query for analytics ───
function buildFiltersFromQuery(query = {}, finalNeighborhoodId = "") {
  const filters = {};

  // Neighborhoods
  const neighborhoodSource = finalNeighborhoodId || query.neighborhoods;
  if (neighborhoodSource) {
    const ids = String(neighborhoodSource)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (ids.length > 0) filters.neighborhoods = ids;
  }

  // Features
  if (query.features) {
    const features = Array.isArray(query.features)
      ? query.features
      : [query.features];
    if (features.length > 0) filters.features = features;
  }

  // Sort
  if (query.sortBy && query.sortBy !== "newest") {
    filters.sort_by = query.sortBy;
  }

  // Range and field values
  const skipKeys = new Set([
    "categories",
    "slug",
    "city",
    "catname",
    "page",
    "per_page",
    "categoryId",
    "category_id",
    "features",
    "neighborhoods",
    "sortBy",
    "sort_by",
    "sort_order",
  ]);

  Object.keys(query).forEach((key) => {
    if (skipKeys.has(key)) return;
    if (isTrackingParam(key)) return; 
    const raw = query[key];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (value === undefined || value === null || value === "") return;
    filters[key] = value;
  });

  return filters;
}

function stripTrailingSlash(url) {
  return String(url || "").replace(/\/+$/, "");
}

function safePathSegment(v) {
  return encodeURIComponent(String(v || "").trim());
}

function buildCanonical({
  city,
  category,
  neighborhoodSlug,
  hasMultipleNeighborhoods,
  hasQueryNeighborhood,
}) {
  const validCity = city || "tehran";
  const validCategory = category || "";

  if (!validCategory) return `https://boomlex.ir/${safePathSegment(validCity)}`;

  if (neighborhoodSlug && !hasMultipleNeighborhoods && !hasQueryNeighborhood) {
    return `https://boomlex.ir/${safePathSegment(validCity)}/${safePathSegment(
      validCategory
    )}/${safePathSegment(neighborhoodSlug)}`;
  }

  return `https://boomlex.ir/${safePathSegment(validCity)}/${safePathSegment(validCategory)}`;
}

function buildWebPageJsonLd({ canonicalUrl, seoTitle, seoDescription }) {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    "@id": `${stripTrailingSlash(canonicalUrl)}#webpage`,
    url: canonicalUrl,
    name: seoTitle,
    description: seoDescription,
    inLanguage: "fa-IR",
    isPartOf: {
      "@type": "WebSite",
      "@id": "https://boomlex.ir/#website",
      url: "https://boomlex.ir/",
      name: "بوملکس - مشاور املاک هوشمند",
    },
  };
}

function buildOrganizationJsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "RealEstateAgent",
    "@id": "https://boomlex.ir/#realestateagent",
    name: "بوملکس",
    url: "https://boomlex.ir/",
    logo: {
      "@type": "ImageObject",
      url: "https://api.boomlex.ir/logo/og-default.jpg",
    },
    sameAs: [],
  };
}

function hasNonCanonicalQuery(query) {
  if (!query) return false;
  return Object.keys(query).some(
    (k) => k !== "categories" && k !== "slug"
  );
}

const SingleCategory = ({
  initialWorkers = [],
  initialSpecialWorkers = [],
  initialPagination = {
    current_page: 1,
    per_page: 10,
    total_count: 0,
    total_pages: 1,
  },
  initialDetails = {},
  initialMainCats = [],
  initialNeighborhoods = [],
  initialSeoNeighborhoods = [],
  initialFeatures = [],
  initialError = false,
  initialErrorMessage = "",
  initialNonCanonical = false,
  cityFromServer,
  nameFromServer,
  neighborhoodFromServer,
  __clientIp = null,
}) => {
  const router = useRouter();
  const routerSlugArray = getSlugArray(router.query?.slug);

  const city = useMemo(() => {
    const routeCity = router.isReady
      ? getSingleParam(router.query?.categories)
      : "";
    return routeCity || cityFromServer || "tehran";
  }, [router.isReady, router.query?.categories, cityFromServer]);

  const slugName = useMemo(() => {
    const routeSlug = router.isReady ? routerSlugArray[0] : "";
    return routeSlug || nameFromServer || "";
  }, [router.isReady, routerSlugArray, nameFromServer]);

  const routeNeighborhoodSlug = useMemo(() => {
    const fromRoute = router.isReady ? routerSlugArray[1] || "" : "";
    return fromRoute || (!router.isReady ? neighborhoodFromServer || "" : "");
  }, [router.isReady, routerSlugArray, neighborhoodFromServer]);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const [workersState, set_workers] = useState(initialWorkers);
  const [SpecialworkersState, set_special_workers] = useState(initialSpecialWorkers);
  const [pagination, setPagination] = useState(initialPagination);

  const [filterLoading, setFilterLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);

  const [error, setError] = useState(initialError);
  const [errorMessage, setErrorMessage] = useState(initialErrorMessage);

  const [details, setDetails] = useState(initialDetails);
  const [main_cats] = useState(initialMainCats);
  const [neighborhoods] = useState(initialNeighborhoods);
  const [seoNeighborhoods, setSeoNeighborhoods] = useState(initialSeoNeighborhoods);

  const [activeFilterCount] = useState(0);

  const [pendingNeighborhood, setPendingNeighborhood] = useState(null);
  const [routeChanging, setRouteChanging] = useState(false);
  const [showSpinner, setShowSpinner] = useState(false);

  const [isClient, setIsClient] = useState(false);

  const [hydratedKey, setHydratedKey] = useState("ssr");

  const isFirstRender = useRef(true);

  useEffect(() => {
    setIsClient(true);
    setHydratedKey("csr");
  }, []);

  const isNonCanonical = useMemo(() => {
    if (router.isReady) {
      return hasNonCanonicalQuery(router.query);
    }
    return initialNonCanonical;
  }, [router.isReady, router.query, initialNonCanonical]);

  const robotsMeta = isNonCanonical
    ? "noindex, follow"
    : "index, follow, max-image-preview:large";

  const persian_city = useMemo(() => getPersianCityName(city), [city]);

  const persian_category_name =
    details?.name ||
    main_cats.find((c) => c.eng_name === slugName)?.name ||
    "";

  const queryNeighborhood = getSingleParam(router.query?.neighborhoods);
  const hasQueryNeighborhood = Boolean(queryNeighborhood);
  const hasMultipleNeighborhoods = isMultiNeighborhoodValue(queryNeighborhood);

  const activeNeighborhoodValue = hasQueryNeighborhood
    ? queryNeighborhood
    : routeNeighborhoodSlug;

  const neighborhoodObject = useMemo(() => {
    return findNeighborhoodBySlugOrId(neighborhoods, activeNeighborhoodValue);
  }, [neighborhoods, activeNeighborhoodValue]);

  const neighborhoodId = useMemo(() => {
    if (hasQueryNeighborhood) return queryNeighborhood;
    if (neighborhoodObject?.id) return neighborhoodObject.id;
    return "";
  }, [hasQueryNeighborhood, queryNeighborhood, neighborhoodObject]);

  const neighborhoodName = useMemo(() => {
    if (hasMultipleNeighborhoods) return "";
    if (neighborhoodObject?.name) return neighborhoodObject.name;
    if (neighborhoodObject?.title) return neighborhoodObject.title;
    return getNeighborhoodDisplayName(neighborhoods, activeNeighborhoodValue);
  }, [
    hasMultipleNeighborhoods,
    neighborhoodObject,
    neighborhoods,
    activeNeighborhoodValue,
  ]);

  const neighborhoodDescription = useMemo(() => {
    if (hasMultipleNeighborhoods) return "";
    if (!neighborhoodObject) return "";
    return (
      neighborhoodObject?.description ||
      neighborhoodObject?.desc ||
      neighborhoodObject?.content ||
      ""
    );
  }, [neighborhoodObject, hasMultipleNeighborhoods]);

  const totalCount = useMemo(
    () => pagination.total_count || workersState.length,
    [pagination, workersState]
  );

  const hasMore = useMemo(() => {
    return pagination.current_page < pagination.total_pages;
  }, [pagination]);

  const canonicalUrl = useMemo(() => {
    return buildCanonical({
      city,
      category: slugName,
      neighborhoodSlug: routeNeighborhoodSlug,
      hasMultipleNeighborhoods,
      hasQueryNeighborhood,
    });
  }, [
    city,
    slugName,
    routeNeighborhoodSlug,
    hasMultipleNeighborhoods,
    hasQueryNeighborhood,
  ]);

  const finalSeoNeighborhoods = useMemo(() => {
    if (seoNeighborhoods && seoNeighborhoods.length > 0) {
      return seoNeighborhoods;
    }
    if (!neighborhoods || neighborhoods.length === 0) return [];

    return neighborhoods.map((n) => ({
      city_slug: city,
      cat_slug: slugName,
      cat_name: persian_category_name || "آگهی املاک",
      neighborhood_slug: n.eng_name || n.slug || n.id,
      neighborhood_name: n.name || n.title,
    }));
  }, [seoNeighborhoods, neighborhoods, city, slugName, persian_category_name]);

  const handleCardClick = () => {
    saveCurrentScroll();
  };

  useEffect(() => {
    const handleStart = () => setRouteChanging(true);
    const handleComplete = () => {
      setRouteChanging(false);
      setPendingNeighborhood(null);
    };
    const handleError = () => {
      setRouteChanging(false);
      setPendingNeighborhood(null);
    };

    router.events.on("routeChangeStart", handleStart);
    router.events.on("routeChangeComplete", handleComplete);
    router.events.on("routeChangeError", handleError);

    return () => {
      router.events.off("routeChangeStart", handleStart);
      router.events.off("routeChangeComplete", handleComplete);
      router.events.off("routeChangeError", handleError);
    };
  }, [router]);

  useEffect(() => {
    if (!routeChanging) {
      setShowSpinner(false);
      return;
    }
    const t = setTimeout(() => setShowSpinner(true), 150);
    return () => clearTimeout(t);
  }, [routeChanging]);

  useEffect(() => {
    if (!router.isReady) return;
    if (!routeNeighborhoodSlug) return;
    if (!hasMultipleNeighborhoods) return;
    if (!slugName || !city) return;

    const cleanedQuery = cleanRouterQuery(router.query);

    router.replace(
      {
        pathname: `/${city}/${slugName}`,
        query: {
          ...cleanedQuery,
          page: cleanedQuery.page || 1,
          neighborhoods: queryNeighborhood,
        },
      },
      undefined,
      { shallow: true, scroll: false }
    );
  }, [
    router.isReady,
    router.query,
    routeNeighborhoodSlug,
    hasMultipleNeighborhoods,
    city,
    slugName,
    queryNeighborhood,
    router,
  ]);

  // ---- Data Fetching ----
  useEffect(() => {
    if (!router.isReady) return;
    if (!slugName || !city) return;

    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }

    if (routeNeighborhoodSlug && hasMultipleNeighborhoods) return;

    const fetchFilteredWorkers = async () => {
      try {
        setFilterLoading(true);
        setError(false);
        setErrorMessage("");

        const query = router.query || {};
        const page = query.page ? parseInt(getSingleParam(query.page), 10) : 1;
        const per_page = pagination.per_page || 10;

        const finalNeighborhoodId = queryNeighborhood || neighborhoodId || "";

        const apiUrl = buildWorkersApiUrl({
          catname: slugName,
          city,
          page,
          per_page,
          query,
          finalNeighborhoodId,
        });

        const response = await axios.get(apiUrl, {
          timeout: 10000,
          headers: { Accept: "application/json" },
        });

        const data = response.data;

        // ─── Compute result counts for analytics ───
        const resultCount =
          data.pagination?.total_count ?? (data.workers || []).length;
        const returnedCount = (data.workers || []).length;

        set_workers(data.workers || []);
        set_special_workers(data.special_workers || []);
        if (data.the_city_category_neighborhoods) {
          setSeoNeighborhoods(data.the_city_category_neighborhoods);
        }

        setPagination(
          data.pagination || {
            current_page: page,
            per_page,
            total_count: data.workers?.length || 0,
            total_pages: 1,
          }
        );

        if (data?.filters_applied?.persian_category_name) {
          setDetails({
            name: data.filters_applied.persian_category_name,
            id: data.filters_applied.category_id,
          });
        }

        // ─── Analytics: filter_apply (with result counts) ───
        // Fire AFTER the API responds, so we know how many properties matched.
        // Fires on every router.asPath change (after the first render) — i.e.,
        // every user-triggered filter change.
        const filtersForAnalytics = buildFiltersFromQuery(query, finalNeighborhoodId);
        const isReset = Object.keys(filtersForAnalytics).length === 0;

        trackEvent(
          "filter_apply",
          {
            city_slug: city,
            category_slug: slugName,
            filters: filtersForAnalytics,
            filters_count: Object.keys(filtersForAnalytics).length,
            results_count: resultCount,
            returned_count: returnedCount,
            has_neighborhoods: !!filtersForAnalytics.neighborhoods,
            has_features: !!filtersForAnalytics.features,
            has_sort: !!filtersForAnalytics.sort_by,
            is_reset: isReset,
          },
          __clientIp
        );
      } catch (e) {
        console.error("Client filter fetch error:", e);
        setError(true);
        setErrorMessage("خطا در دریافت اطلاعات. لطفا بعدا تلاش کنید.");
      } finally {
        setFilterLoading(false);
      }
    };

    fetchFilteredWorkers();
  }, [
    router.isReady,
    router.asPath,
    slugName,
    city,
    routeNeighborhoodSlug,
    hasMultipleNeighborhoods,
    queryNeighborhood,
    neighborhoodId,
    pagination.per_page,
    __clientIp,
  ]);

  const buildPageHref = useCallback(
    (pageNum) => {
      const basePath = routeNeighborhoodSlug
        ? `/${city}/${slugName}/${routeNeighborhoodSlug}`
        : `/${city}/${slugName}`;

      const q = { ...(router.query || {}) };
      delete q.categories;
      delete q.slug;

      if (pageNum === 1) {
        delete q.page;
      } else {
        q.page = String(pageNum);
      }

      return { pathname: basePath, query: q };
    },
    [city, slugName, routeNeighborhoodSlug, router.query]
  );

  const goToPage = useCallback(
    async (pageNum) => {
      if (pageNum < 1) return;
      if (pageNum === pagination.current_page) return;

      setLoadingMore(true);
      setError(false);
      setErrorMessage("");

      try {
        const query = router.query || {};
        const per_page = pagination.per_page || 10;
        const finalNeighborhoodId = queryNeighborhood || neighborhoodId || "";

        const apiUrl = buildWorkersApiUrl({
          catname: slugName,
          city,
          page: pageNum,
          per_page,
          query,
          finalNeighborhoodId,
        });

        const response = await axios.get(apiUrl, {
          timeout: 10000,
          headers: { Accept: "application/json" },
        });

        const data = response.data;

        set_workers(data.workers || []);
        set_special_workers(data.special_workers || []);
        if (data.the_city_category_neighborhoods) {
          setSeoNeighborhoods(data.the_city_category_neighborhoods);
        }

        setPagination(
          data.pagination || {
            current_page: pageNum,
            per_page,
            total_count: data.workers?.length || 0,
            total_pages: 1,
          }
        );

        const href = buildPageHref(pageNum);
        router.push(href, undefined, { shallow: true, scroll: false });

        if (typeof window !== "undefined") {
          window.scrollTo({ top: 0, behavior: "smooth" });
        }
      } catch (e) {
        console.error("Error loading page:", e);
        setError(true);
        setErrorMessage("خطا در دریافت اطلاعات. لطفا بعدا تلاش کنید.");
      } finally {
        setLoadingMore(false);
      }
    },
    [
      pagination.current_page,
      pagination.per_page,
      router,
      slugName,
      city,
      queryNeighborhood,
      neighborhoodId,
      buildPageHref,
    ]
  );

  const loadMoreWorkers = useCallback(async () => {
    if (loadingMore || !hasMore) return;

    setLoadingMore(true);
    const nextPage = pagination.current_page + 1;

    try {
      const query = router.query || {};
      const finalNeighborhoodId = queryNeighborhood || neighborhoodId || "";

      const apiUrl = buildWorkersApiUrl({
        catname: slugName,
        city,
        page: nextPage,
        per_page: pagination.per_page,
        query,
        finalNeighborhoodId,
      });

      const response = await axios.get(apiUrl, {
        timeout: 10000,
        headers: { Accept: "application/json" },
      });

      const data = response.data;

      set_workers((prev) => {
        const existingIds = new Set(prev.map((w) => w.id));
        const newWorkers = (data.workers || []).filter((w) => !existingIds.has(w.id));
        return [...prev, ...newWorkers];
      });

      setPagination(
        data.pagination || {
          current_page: nextPage,
          per_page: pagination.per_page,
          total_count: pagination.total_count,
          total_pages: pagination.total_pages,
        }
      );
    } catch (e) {
      console.error("Error loading more workers:", e);
    } finally {
      setLoadingMore(false);
    }
  }, [
    loadingMore,
    hasMore,
    pagination,
    router.query,
    slugName,
    city,
    queryNeighborhood,
    neighborhoodId,
  ]);

  const seoTitle = useMemo(() => {
    const categoryName = persian_category_name || slugName || "آگهی";
    const cityName = persian_city || city || "تهران";

    if (neighborhoodName) {
      if (totalCount > 0) {
        return `${categoryName} در ${neighborhoodName} ${cityName} | لیست ${totalCount} آگهی | بوملکس`;
      }
      return `${categoryName} در ${neighborhoodName} ${cityName} | بوملکس`;
    }

    if (totalCount > 0) {
      return `${categoryName} در ${cityName} | لیست ${totalCount} آگهی | بوملکس`;
    }

    return `${categoryName} در ${cityName} | بوملکس`;
  }, [persian_category_name, persian_city, neighborhoodName, totalCount, slugName, city]);

  const seoDescription = useMemo(() => {
    const categoryName = persian_category_name || slugName || "آگهی";
    const cityName = persian_city || city || "تهران";

    if (neighborhoodName && neighborhoodDescription) {
      return neighborhoodDescription.slice(0, 155);
    }

    if (neighborhoodName) {
      if (totalCount > 0) {
        return `${totalCount} آگهی ${categoryName} در ${neighborhoodName} ${cityName}. جدیدترین فایل‌ها، قیمت‌ها و مشخصات را در بوملکس ببینید.`;
      }
      return `جدیدترین آگهی‌های ${categoryName} در ${neighborhoodName} ${cityName} در بوملکس.`;
    }

    if (totalCount > 0) {
      return `${totalCount} آگهی ${categoryName} در ${cityName}. جدیدترین فایل‌ها، قیمت‌ها و مشخصات را در بوملکس ببینید.`;
    }

    return `جدیدترین آگهی‌های ${categoryName} در ${cityName} در بوملکس.`;
  }, [
    persian_category_name,
    persian_city,
    neighborhoodName,
    neighborhoodDescription,
    totalCount,
    slugName,
    city,
  ]);

  const seoImage = details?.avatar
    ? `https://api.boomlex.ir/cats_image/${details.avatar}.jpg`
    : "https://api.boomlex.ir/logo/og-default.jpg";

  const breadcrumbJsonLd = useMemo(() => {
    const displayName = persian_category_name || slugName || "آگهی";
    const cityName = persian_city || city || "تهران";
    const validCitySlug = city || "tehran";
    const validCategorySlug = slugName || "";

    const items = [
      {
        "@type": "ListItem",
        position: 1,
        name: "خانه",
        item: "https://boomlex.ir/",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: cityName,
        item: `https://boomlex.ir/${safePathSegment(validCitySlug)}`,
      },
    ];

    if (validCategorySlug) {
      items.push({
        "@type": "ListItem",
        position: 3,
        name: displayName,
        item: `https://boomlex.ir/${safePathSegment(validCitySlug)}/${safePathSegment(
          validCategorySlug
        )}`,
      });
    }

    if (neighborhoodName && validCategorySlug) {
      items.push({
        "@type": "ListItem",
        position: 4,
        name: neighborhoodName,
        item: canonicalUrl,
      });
    }

    return {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: items,
    };
  }, [persian_category_name, slugName, persian_city, city, neighborhoodName, canonicalUrl]);

  const collectionJsonLd = useMemo(() => {
    const items = (workersState || []).slice(0, 10).map((worker, index) => {
      const price = normalizePriceToIRR(worker?.price || worker?.specialvalue2);
      const image = worker?.thumb || worker?.image || seoImage;
      const url = `https://boomlex.ir/worker/${worker.id}?slug=${worker.slug || ""}`;

      return {
        "@type": "ListItem",
        position: index + 1,
        url,
        item: {
          "@type": "RealEstateListing",
          name: worker.name || `${persian_category_name} در ${persian_city}`,
          url,
          image,
          ...(price
            ? {
                offers: {
                  "@type": "Offer",
                  price,
                  priceCurrency: "IRR",
                },
              }
            : {}),
        },
      };
    });

    return {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: seoTitle,
      description: seoDescription,
      url: canonicalUrl,
      mainEntity: {
        "@type": "ItemList",
        numberOfItems: totalCount,
        itemListElement: items,
      },
    };
  }, [
    workersState,
    seoTitle,
    seoDescription,
    canonicalUrl,
    totalCount,
    persian_category_name,
    persian_city,
    seoImage,
  ]);

  const webPageJsonLd = useMemo(() => {
    return buildWebPageJsonLd({ canonicalUrl, seoTitle, seoDescription });
  }, [canonicalUrl, seoTitle, seoDescription]);

  const orgJsonLd = useMemo(() => buildOrganizationJsonLd(), []);

  const renderSpinner = () => (
    <div
      className="spinnerImageView"
      style={{
        minHeight: "60vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "white",
      }}
    >
      <div
        style={{
          position: "relative",
          width: "400px",
          height: "400px",
          marginBottom: "20px",
        }}
      >
        <Image
          src="/logo/ajour-gif.gif"
          alt="در حال بارگذاری"
          fill
          sizes="400px"
          style={{ objectFit: "contain" }}
          priority
        />
      </div>
    </div>
  );

  const renderBreadcrumb = () => {
    const displayName = persian_category_name || slugName || "آگهی";
    const cityName = persian_city || city || "تهران";

    return (
      <div
        style={{
          padding: "20px 20px",
          paddingTop: isMobile ? "70px" : "1px",
          marginBottom: "10px",
          marginTop: "20px",
          borderRadius: "8px",
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
        }}
      >
        <Breadcrumbs aria-label="breadcrumb" separator="›" sx={{ direction: "rtl" }}>
          <Link href="/" passHref legacyBehavior>
            <Box
              component="a"
              sx={{
                display: "flex",
                alignItems: "center",
                color: "#666",
                textDecoration: "none",
                fontSize: "14px",
                "&:hover": { color: "#7a97ff" },
              }}
            >
              <HomeIcon sx={{ fontSize: "16px", ml: 0.5 }} />
              خانه
            </Box>
          </Link>

          <Link href={`/${city}`} passHref legacyBehavior>
            <Box
              component="a"
              sx={{
                display: "flex",
                alignItems: "center",
                color: "#666",
                textDecoration: "none",
                fontSize: "14px",
                "&:hover": { color: "#7a97ff" },
              }}
            >
              <LocationOnIcon sx={{ fontSize: "16px", ml: 0.5 }} />
              {cityName}
            </Box>
          </Link>

          {neighborhoodName && slugName ? (
            <Link href={`/${city}/${slugName}`} passHref legacyBehavior>
              <Box
                component="a"
                sx={{
                  display: "flex",
                  alignItems: "center",
                  color: "#666",
                  textDecoration: "none",
                  fontSize: "14px",
                  "&:hover": { color: "#7a97ff" },
                }}
              >
                <CategoryIcon sx={{ fontSize: "16px", ml: 0.5 }} />
                {displayName}
              </Box>
            </Link>
          ) : (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                color: "#7a97ff",
                fontWeight: "500",
                fontSize: "14px",
              }}
            >
              <CategoryIcon sx={{ fontSize: "16px", ml: 0.5 }} />
              {displayName}
            </Box>
          )}

          {neighborhoodName && (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                color: "#7a97ff",
                fontWeight: "500",
                fontSize: "14px",
              }}
            >
              <LocationOnIcon sx={{ fontSize: "16px", ml: 0.5 }} />
              {neighborhoodName}
            </Box>
          )}
        </Breadcrumbs>
      </div>
    );
  };

  const renderHeader = () => {
    return (
      <div style={{ backgroundColor: "white" }}>
        <FilterComponent
          initialCategoryId={details?.id || null}
          availableNeighborhoods={neighborhoods}
          availableFeatures={initialFeatures}
          top={70}
          clientIp={__clientIp}
          currentCategorySlug={slugName}
          currentCitySlug={city}
        />
      </div>
    );
  };

  const renderSpecialWorkers = () => {
    if (filterLoading) {
      return (
        <>
          {[1, 2, 3].map((n) => (
            <CardSkeleton key={n} />
          ))}
        </>
      );
    }

    if (error) {
      return (
        <Grid item xs={12}>
          <Alert severity="error">{errorMessage || "خطایی رخ داده است"}</Alert>
        </Grid>
      );
    }

    if (SpecialworkersState && SpecialworkersState.length > 0 && activeFilterCount < 1) {
      return (
        <>
          {SpecialworkersState.map((worker) => (
            <Grid
              item
              xs={12}
              sm={6}
              md={4}
              key={`special-${hydratedKey}-${worker.id}`}
              sx={{ display: "flex", justifyContent: "center" }}
            >
              <Link
                href={`/worker/${worker.id}?slug=${worker.slug}`}
                passHref
                scroll={false}
                style={{ width: "100%", textDecoration: "none" }}
                prefetch={false}
              >
                <MemoizedWorkerCard worker={worker} />
              </Link>
            </Grid>
          ))}
        </>
      );
    }

    return null;
  };

  const renderWorkers = () => {
    if (filterLoading) {
      return (
        <>
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <CardSkeleton key={n} />
          ))}
        </>
      );
    }

    if (error) {
      return (
        <Grid item xs={12}>
          <Alert severity="error">{errorMessage || "خطایی رخ داده است"}</Alert>
        </Grid>
      );
    }

    if (workersState && workersState.length > 0) {
      return (
        <>
          {workersState.map((worker) => (
            <Grid
              item
              xs={12}
              sm={6}
              md={4}
              key={`worker-${hydratedKey}-${worker.id}`}
              sx={{ display: "flex", justifyContent: "center" }}
            >
              <Link
                href={`/worker/${worker.id}?slug=${worker.slug}`}
                passHref
                scroll={false}
                style={{ width: "100%", textDecoration: "none" }}
                prefetch={false}
              >
                <MemoizedWorkerCard worker={worker} />
              </Link>
            </Grid>
          ))}
        </>
      );
    }

    return (
      <Grid item xs={12}>
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            py: 5,
          }}
        >
          <img
            src="/logo/not-found.png"
            alt="ملکی پیدا نشد"
            width={200}
            height={120}
            loading="lazy"
            style={{ opacity: 0.7 }}
          />
          <p style={{ marginTop: 20, color: "#666", fontSize: 16 }}>
            متاسفانه موردی یافت نشد
          </p>
        </Box>

        <FileRequest
          onCallClick={() => {
            window.location.href = "tel:+989382740488";
          }}
          onActionClick={() => router.push("/file-request")}
        />
      </Grid>
    );
  };

  const renderPagination = () => {
    const current = pagination.current_page || 1;
    const total = pagination.total_pages || 1;
    if (total <= 1) return null;

    const pages = [];
    const start = Math.max(1, current - 3);
    const end = Math.min(total, start + 6);
    for (let i = start; i <= end; i++) pages.push(i);

    const btnSx = (active, disabled) => ({
      minWidth: 40,
      height: 40,
      px: 1.25,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "8px",
      border: "1px solid",
      borderColor: active ? "#7a97ff" : "#e0e0e0",
      backgroundColor: active ? "#7a97ff" : "#fff",
      color: active ? "#fff" : disabled ? "#bbb" : "#333",
      fontSize: 14,
      fontWeight: active ? 700 : 500,
      textDecoration: "none",
      cursor: disabled ? "default" : "pointer",
      pointerEvents: disabled ? "none" : "auto",
      transition: "all 0.15s ease",
      fontFamily: "'Vazir','IRANSans','Segoe UI',sans-serif",
      "&:hover": {
        backgroundColor: active ? "#7a97ff" : "#fafafa",
        borderColor: active ? "#7a97ff" : "#7a97ff",
        color: active ? "#fff" : "#7a97ff",
      },
    });

    const handleClick = (e, pageNum) => {
      if (loadingMore) {
        e.preventDefault();
        return;
      }
      e.preventDefault();
      goToPage(pageNum);
    };

    return (
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          gap: 1,
          mt: 4,
          mb: 2,
          direction: "rtl",
          flexWrap: "wrap",
          px: { xs: 2, sm: 3 },
        }}
      >
        <Link href={buildPageHref(Math.max(1, current - 1))} passHref legacyBehavior>
          <Box
            component="a"
            onClick={(e) => handleClick(e, Math.max(1, current - 1))}
            sx={btnSx(false, current === 1)}
          >
            قبلی
          </Box>
        </Link>

        {pages.map((p) => (
          <Link key={p} href={buildPageHref(p)} passHref legacyBehavior>
            <Box
              component="a"
              onClick={(e) => handleClick(e, p)}
              sx={btnSx(p === current, false)}
            >
              {p}
            </Box>
          </Link>
        ))}

        <Link
          href={buildPageHref(Math.min(total, current + 1))}
          passHref
          legacyBehavior
        >
          <Box
            component="a"
            onClick={(e) => handleClick(e, Math.min(total, current + 1))}
            sx={btnSx(false, current === total)}
          >
            بعدی
          </Box>
        </Link>
      </Box>
    );
  };

  const h1Text = neighborhoodName
    ? `${persian_category_name || "آگهی"} در ${neighborhoodName} ${persian_city || "تهران"}`
    : `${persian_category_name || "آگهی"} در ${persian_city || "تهران"}`;

  const introText = neighborhoodName
    ? `لیست آگهی‌های ${persian_category_name || "آگهی"} در ${neighborhoodName} ${persian_city || "تهران"} به همراه قیمت، تصاویر و مشخصات. برای دیدن جزئیات هر فایل روی آن کلیک کنید.`
    : `لیست آگهی‌های ${persian_category_name || "آگهی"} در ${persian_city || "تهران"} به همراه قیمت، تصاویر و مشخصات. برای دیدن جزئیات هر فایل روی آن کلیک کنید.`;

  return (
    <div className="realstate-contents-wrapper">
      <Head>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta httpEquiv="Content-Language" content="fa" />

        <title>{seoTitle}</title>
        <meta name="description" content={seoDescription} />

        <meta name="robots" content={robotsMeta} />
        <meta name="googlebot" content={robotsMeta} />

        <link rel="canonical" href={canonicalUrl} />

        <meta property="og:locale" content="fa_IR" />
        <meta property="og:type" content="website" />
        <meta property="og:site_name" content="بوملکس - مشاور املاک هوشمند" />
        <meta property="og:title" content={seoTitle} />
        <meta property="og:description" content={seoDescription} />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content={seoImage} />
        <meta property="og:image:width" content="1200" />
        <meta property="og:image:height" content="630" />
      </Head>

      <Script
        id="breadcrumb-jsonld"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }}
      />

      <Script
        id="collection-jsonld"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(collectionJsonLd) }}
      />

      <Script
        id="webpage-jsonld"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(webPageJsonLd) }}
      />

      <Script
        id="organization-jsonld"
        type="application/ld+json"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
      />

      <div className={Styles["realstate-items-wrapper"]}>
        <div className={Styles["main-wrapper"]}>
          {renderHeader()}
          {renderBreadcrumb()}

          <Box
            sx={{
              px: { xs: 2, sm: 3 },
              mt: 1,
              mb: 2,
              textAlign: "center",
              direction: "rtl",
            }}
          >
            <Box
              component="h1"
              sx={{
                m: 0,
                mb: 1,
                fontWeight: 700,
                lineHeight: 1.4,
                fontSize: { xs: "18px", sm: "20px" },
                color: "#111",
              }}
            >
              {h1Text}
            </Box>

            <Box
              component="p"
              sx={{
                m: 0,
                mx: "auto",
                maxWidth: 720,
                color: "text.secondary",
                lineHeight: 1.9,
                fontSize: { xs: "12.5px", sm: "13.5px" },
              }}
            >
              {introText}
            </Box>

            {neighborhoodDescription && (
              <Box
                sx={{
                  mt: 3,
                  mx: "auto",
                  maxWidth: 850,
                  p: 3,
                  borderRadius: 2,
                  backgroundColor: "#fafafa",
                  border: "1px solid #eee",
                  textAlign: "right",
                  direction: "rtl",
                  lineHeight: 2,
                  fontSize: { xs: "13px", sm: "14px" },
                  color: "#444",
                }}
              >
                {neighborhoodDescription}
              </Box>
            )}
          </Box>

          {showSpinner ? (
            renderSpinner()
          ) : (
            <>
              <Box sx={{ flexGrow: 1, py: 3, px: { xs: 2, sm: 3 } }}>
                <Grid
                  container
                  spacing={{ xs: 2, sm: 3 }}
                  justifyContent={{ xs: "center", sm: "flex-start" }}
                >
                  {renderSpecialWorkers()}
                </Grid>
              </Box>

              <Box sx={{ flexGrow: 1, py: 3, px: { xs: 2, sm: 3 } }}>
                <Grid
                  container
                  spacing={{ xs: 2, sm: 3 }}
                  justifyContent={{ xs: "center", sm: "flex-start" }}
                >
                  {renderWorkers()}
                </Grid>
              </Box>

              {!filterLoading && !error && workersState.length > 0 && renderPagination()}
            </>
          )}

          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              gap: 1.5,
              mt: 2,
              direction: "rtl",
              opacity: routeChanging ? 0.5 : 1,
              pointerEvents: routeChanging ? "none" : "auto",
              transition: "opacity 0.2s ease",
            }}
          >
            {finalSeoNeighborhoods.map((item, index) => {
              const isPending =
                routeChanging &&
                pendingNeighborhood === item.neighborhood_slug;

              return (
                <Link
                  key={index}
                  href={`/${item.city_slug}/${item.cat_slug}/${item.neighborhood_slug}`}
                  style={{ textDecoration: "none" }}
                  onClick={() => setPendingNeighborhood(item.neighborhood_slug)}
                >
                  <Box
                    sx={{
                      px: 2,
                      py: 1,
                      borderRadius: "8px",
                      backgroundColor: isPending ? "#7a97ff" : "#f5f5f5",
                      border: "1px solid",
                      borderColor: isPending ? "#7a97ff" : "#e0e0e0",
                      fontSize: "13.5px",
                      color: isPending ? "#fff" : "#333",
                      transition: "all 0.2s ease",
                      "&:hover": {
                        backgroundColor: "#7a97ff",
                        color: "#fff",
                        borderColor: "#7a97ff",
                      },
                    }}
                  >
                    {item.cat_name} در {item.neighborhood_name}
                  </Box>
                </Link>
              );
            })}
          </Box>
        </div>
      </div>
    </div>
  );
};

export default SingleCategory;

SingleCategory.propTypes = {
  initialWorkers: PropTypes.array,
  initialSpecialWorkers: PropTypes.array,
  initialPagination: PropTypes.object,
  initialDetails: PropTypes.object,
  initialMainCats: PropTypes.array,
  initialNeighborhoods: PropTypes.array,
  initialSeoNeighborhoods: PropTypes.array,
  initialFeatures: PropTypes.array,
  initialError: PropTypes.bool,
  initialErrorMessage: PropTypes.string,
  initialNonCanonical: PropTypes.bool,
  cityFromServer: PropTypes.string,
  nameFromServer: PropTypes.string,
  neighborhoodFromServer: PropTypes.string,
  __clientIp: PropTypes.string,
};

export async function getServerSideProps(context) {
  const { categories, slug = [] } = context.params || {};

  const slugArray = Array.isArray(slug) ? slug : [];

  const city = categories || "tehran";
  const catname = slugArray[0] || "";
  const neighborhoodSlug = slugArray[1] || "";

  const query = context.query || {};
  const page = query.page ? parseInt(getSingleParam(query.page), 10) : 1;
  const per_page = 10;

  if (!catname) {
    return {
      notFound: true,
    };
  }

  context.res.setHeader(
    'Cache-Control',
    'public, s-maxage=60, stale-while-revalidate=120'
  );

  const pageUrl = `https://boomlex.ir/${city}/${catname}${
    neighborhoodSlug ? `/${neighborhoodSlug}` : ""
  }`;
  const clientContext = buildClientContext(context, pageUrl);

  const initialNonCanonical = hasNonCanonicalQuery(query);

  let baseData = null;

  try {
    const baseRes = await axios.get(
      `https://api.boomlex.ir/api/base?city=${encodeURIComponent(city)}`,
      {
        timeout: 10000,
        headers: { Accept: "application/json" },
      }
    );

    baseData = baseRes.data;
  } catch (e) {
    console.error("Base fetch error:", e);
  }

  const queryNeighborhood = getSingleParam(query.neighborhoods);
  const hasQueryNeighborhood = Boolean(queryNeighborhood);
  const hasMultipleNeighborhoods = isMultiNeighborhoodValue(queryNeighborhood);

  if (neighborhoodSlug && hasMultipleNeighborhoods) {
    const cleanedQuery = cleanRouterQuery(query);

    return {
      redirect: {
        destination: `/${city}/${catname}?${new URLSearchParams({
          ...cleanedQuery,
          page: String(cleanedQuery.page || 1),
          neighborhoods: queryNeighborhood,
        }).toString()}`,
        permanent: false,
      },
    };
  }

  let resolvedNeighborhood = null;

  if (!hasQueryNeighborhood && neighborhoodSlug && baseData?.the_neighborhoods) {
    resolvedNeighborhood = findNeighborhoodBySlugOrId(
      baseData.the_neighborhoods,
      neighborhoodSlug
    );
  }

  if (!resolvedNeighborhood && queryNeighborhood && baseData?.the_neighborhoods) {
    resolvedNeighborhood = findNeighborhoodBySlugOrId(
      baseData.the_neighborhoods,
      queryNeighborhood
    );
  }

  const finalNeighborhoodId = hasQueryNeighborhood
    ? queryNeighborhood
    : resolvedNeighborhood?.id || "";

  const apiUrl = buildWorkersApiUrl({
    catname,
    city,
    page,
    per_page,
    query,
    finalNeighborhoodId,
  });

  try {
    const workersRes = await axios.get(apiUrl, {
      timeout: 10000,
      headers: { Accept: "application/json" },
    });

    const workersData = workersRes.data;

    const initialWorkers = workersData?.workers || [];
    const initialSpecialWorkers = workersData?.special_workers || [];
    const initialSeoNeighborhoods = workersData?.the_city_category_neighborhoods || [];

    const initialPagination =
      workersData?.pagination || {
        current_page: page,
        per_page,
        total_count: initialWorkers.length,
        total_pages: Math.ceil((initialWorkers.length || 0) / per_page),
      };

    const initialDetails = workersData?.filters_applied?.persian_category_name
      ? {
          name: workersData.filters_applied.persian_category_name,
          id: workersData.filters_applied.category_id,
        }
      : {};

    // ─── Analytics: fire category_view (fire-and-forget) ───
        // ─── Analytics: fire category_view (fire-and-forget) ───
    // The Fix: Only track if the category looks real.
    // 1. No dots (blocks favicon.png, .php, .well-known)
    // 2. Length < 30 (blocks long IPFS hashes like bafkreic...)
    // 3. The API actually returned a valid category name/id
    const isRealCategory = 
      catname && 
      !catname.includes(".") && 
      catname.length < 30 &&
      initialDetails?.id;

    if (isRealCategory && (clientContext.clientIp || clientContext.userAgent)) {
      fireSsrEvent(
        "category_view",
        {
          city_slug: city,
          category_slug: catname,
          neighborhood_slug: neighborhoodSlug || null,
          page,
          results_count: initialPagination.total_count || 0,
        },
        clientContext
      ).catch((err) => {
        // eslint-disable-next-line no-console
        console.warn(
          "[ssr] category_view failed:",
          err?.response?.status || err?.message || err
        );
      });
    }

    return {
      props: {
        initialWorkers,
        initialSpecialWorkers,
        initialPagination,
        initialDetails,
        initialMainCats: baseData?.cats || [],
        initialNeighborhoods: baseData?.the_neighborhoods || [],
        initialSeoNeighborhoods,
        initialFeatures: baseData?.features || [],
        initialError: false,
        initialErrorMessage: "",
        initialNonCanonical,
        cityFromServer: city,
        nameFromServer: catname,
        neighborhoodFromServer: neighborhoodSlug,
        __clientIp: clientContext.clientIp,
      },
    };
  } catch (e) {
    console.error("SSR fetch error:", e);

    return {
      props: {
        initialWorkers: [],
        initialSpecialWorkers: [],
        initialPagination: {
          current_page: 1,
          per_page: 10,
          total_count: 0,
          total_pages: 1,
        },
        initialDetails: {},
        initialMainCats: baseData?.cats || [],
        initialNeighborhoods: baseData?.the_neighborhoods || [],
        initialSeoNeighborhoods: [],
        initialFeatures: baseData?.features || [],
        initialError: true,
        initialErrorMessage: "خطا در دریافت اطلاعات. لطفا بعدا تلاش کنید.",
        initialNonCanonical,
        cityFromServer: city,
        nameFromServer: catname,
        neighborhoodFromServer: neighborhoodSlug,
        __clientIp: clientContext.clientIp,
      },
    };
  }
}